<!DOCTYPE html>
<html>
<body>
<?php
	foreach($getCertificate as $getCertificate )
      {
?>
<h1>{{ $getCertificate->firstName }} </h1> You are Genius.

<?php
      }
?>
                                          
</body>
</html>