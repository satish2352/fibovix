<?php $__env->startSection('title'); ?>
    NEWS FEED
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('website.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('website.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="row text-center justify-content-center" style="margin-top: 20;">
      <div class="col-md-12">
          <h1 class=" text-uppercase text-primary">NEWS FEED</h1>

      </div>
  </div>
    <div class="container my-5">
      <div class="card box-shadow-1 mb-2">
        <div class="card-body">
        <div class="row">
            <?php if(count($allDroneNewsFeedList)>0): ?>
             <?php
            foreach($allDroneNewsFeedList as $getallDroneNewsFeedList)
                {
		        ?>
            <div class="col-md-4 mb-2">
              <div class="card box-shadow-1 mb-2">
              <div class="card-body">
               <div class="row no-gutters">
                 <div class="col-md-6 courses-card-image">
                    <center>
                        <?php if($getallDroneNewsFeedList->url): ?>
                      <iframe src="<?php echo e(url($getallDroneNewsFeedList->url)); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" style="height: 150px; width: 160px;" allowfullscreen></iframe>
                      <?php else: ?> <?php echo e('No Video Available'); ?><?php endif; ?>
                    </center>
                 </div>
                 <div class="col-md-2"></div>
                 <div class="col-md-4">
                  
                    <h5 class="card-title"><?php echo e($getallDroneNewsFeedList->title); ?></h5>
                    <p class="card-text"><?php if($getallDroneNewsFeedList->description): ?><?php echo e($getallDroneNewsFeedList->description); ?><?php else: ?> <?php echo e('-'); ?><?php endif; ?></p>
                  
                </div>
                </div>
            </div>
            </div>
            </div>
            <?php
                }
            ?>
            <?php else: ?>
            <div class="card  box-shadow-1 my-2">
                        <div class="card-body">
                             <h5 class="card-title">NEWS FEED</h5>
                            <div class="alert alert-danger" role="alert" >
                                
                                 <span style="align:center">No News Uploaded Yet !! </span>
                                  </div>
                        </div>
                    </div>
            <?php endif; ?>
      </div>
      <br>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rpapilot/public_html/rpa/resources/views/website/DroneNewsFeed.blade.php ENDPATH**/ ?>