<style>
    .display-5 {
             font-size: 2.5rem;
             font-weight: 300;
             line-height: 1.2;
         }
    .display-6 {
        font-size: 2.0rem;
        font-weight: 300;
        line-height: 1.2;
    }
    .display-7 {
        font-size: 1.5rem;
        font-weight: 300;
        line-height: 1.2;
    }
    .display-8 {
        font-size: 1.0rem;
        font-weight: 300;
        line-height: 1.2;
    }
</style>
<?php /**PATH /home/infosolution/public_html/rpa/resources/views/website/style.blade.php ENDPATH**/ ?>