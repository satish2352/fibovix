
<?php $__env->startSection('title'); ?>
    Search FTO
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('website.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('website.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<?php $CommonService = app('App\Http\Controllers\Common\CommonController'); ?>



<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.table-striped tbody tr:nth-of-type(2n+1) 
{

    background-color: #ffcc80;
}
</style>

<div class="container my-5 text-center">
    <br>
            <div class="card box-shadow-1 mb-2" >
              <div class="card-body">
            <div class="row table-responsive" style="margin-left: 1px;">
            <table class="table table-striped " id="pageDataTable" role="grid" aria-describedby="DataTables_Table_0_info">
            <thead>
            <tr>
            <?php
               $count=0;
               ?>
<!--             <th class="table-plus datatable-nosort"></th>
 -->            <th>Sn.</th>
            <th>Title</th>
            <th>Description</th>
            <th>Upload TextBook</th>
            <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <?php if(count($allTPM) > 0): ?>
            <?php
               //dd($allPilots);
                foreach($allTPM as $getalltpm )
                                              {
                                    ?>
            <tr>
            <td><?php echo e(++$count); ?></td>
            
            <td><?php echo e($getalltpm->title); ?></td>
            <td><?php echo e($getalltpm->description); ?></td>
            <td><!-- <img src="public/asset/vendors/upload/<?php echo e($getalltpm->photoUpload); ?>" height="100" width="100" id="preview_img"><br><br> -->
             <a href="public/asset/vendors/upload/<?php echo e($getalltpm->photoUpload); ?>" Download><button type="button" name="download" class="btn btn-success dropdown  ">Download</button></a>
             </td>
            
            <!--  <a href="<?php echo e(route('viewuploadtpm',['alltpmId'=>$getalltpm->id,'deleteOrEditState'=>'editstate'])); ?>" class="btn btn-edit btn-lg">
                                        <i class="icon-copy fi-pencil btngreen" title="Edit"></i>fdbdghb
                                      </a> -->
        
            <td>
              <a class="btn btn-primary" href="#" role="button" >View</a>
            </td>
            </tr>
            <?php
               }
               ?>
            <?php endif; ?>
            </tbody>
            </table>
            </div>
            </div>
          </div>
        </div>


         <script type="text/javascript">
            $(document).ready(function(){
                //Image file input change event
                $("#image").change(function(){
                    readImageData(this);//Call image read and render function
                });
            });
             
            function readImageData(imgData){
                if (imgData.files && imgData.files[0]) {
                    var readerObj = new FileReader();
                    
                    readerObj.onload = function (element) {
                        $('#preview_img').attr('src', element.target.result);
                    }
                    
                    readerObj.readAsDataURL(imgData.files[0]);
                }
            }
        </script>


<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sumagoinfotech/public_html/rpa/resources/views/fto/uploadTPM/viewuploadtpm.blade.php ENDPATH**/ ?>