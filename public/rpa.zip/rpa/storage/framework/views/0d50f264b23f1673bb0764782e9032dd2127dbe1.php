<?php $__env->startSection('title'); ?>
    Event Seaarch
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('website.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('website.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container" style="max-width:1300px;">

        <div class="row">
            <div class="col-md-12 mb-2">
             
             <div class="row no-gutters">
    <div class="col-md-3 courses-card-image" style="background-image: url(http://rpapilot.com/rpa/public//images/events/05-01-2020-657766133.jpg)">
    </div>
    <div class="col-md-9">
      <div class="card-body">
        <h5 class="card-title">Drone Festival of India</h5>
        <p class="card-text">The Drone Festival Of India Hosted In Partnership With The Ministry Of Civil Aviation Of The Government Of India, Startup India And Young Indians And NASSCOM's 10000 Startups Is India’s Largest UAV ...</p>
                        <a class="btn btn-outline-secondary" target="_blank" href="http://rpapilot.com/events/title/Drone+Festival+of+India">Details</a>
      </div>
    </div>
  </div>
  
            </div>
            <div class="col-md-12">
                <div id="loadView"></div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sumagoinfotech/public_html/rpa/resources/views/website/eventsearch.blade.php ENDPATH**/ ?>