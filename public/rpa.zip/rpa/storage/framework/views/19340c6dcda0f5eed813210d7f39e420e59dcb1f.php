<?php $__env->startSection('content'); ?>

<div class="main-container">
		<div class="pd-ltr-20 customscroll customscroll-10-p height-100-p xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Profile</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo e(route('dashpilot')); ?>">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Update Profile</li>
								</ol>
								
    
							</nav>
						</div>
						<div class="col-md-6 col-sm-12 text-right">
							<div class="dropdown">
								<!--<a href="#EventModal" class="btn btn-primary" role="button" data-toggle="modal" data-target="#EventModal">-->
								<!--    Create Event-->
								<!--</a>-->
							</div>
						</div>
					</div>
				</div>
			
				<!-- Export Datatable start -->
				<div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
					<div class="clearfix mb-20">
						<div class="pull-left">
							<h5 class="text-blue">Profile</h5>
						</div>
					</div>
					<?php //dd($particularProfile); ?>
					<div class="row table-responsive " style="overflow: hidden;">
					 <?php $__currentLoopData = $particularProfile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getparticularProfile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					 <?php //dd($getparticularProfile); ?>
                     <form action="<?php echo e(route('updatepilotprofile')); ?>" method="POST" class="mb-5" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                                <div class="form-row justify-content-between">
                                    <div class="form-group col-md-4">
                                        <label for="">First Name <span class="text-primary">*</span></label>
                                        <input name="firstname" type="text" class="form-control" id=""
                                               placeholder="Provide First Name" value="<?php echo e($getparticularProfile->firstName); ?>" required>
                                    </div>
                                    
                                   <div class="form-group col-md-4">
                                        <label for="">Middle Name <span class="text-primary">*</span></label>
                                        <input name="middlename" type="text" class="form-control" id=""
                                               placeholder="Provide Middle Name" value="<?php echo e($getparticularProfile->middleName); ?>" required>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="">Last Name <span class="text-primary">*</span></label>
                                        <input name="lastname" type="text" class="form-control" id=""
                                               placeholder="Provide Last Name" value="<?php echo e($getparticularProfile->lastName); ?>" required>
                                    </div>
                                </div>
                                
                                <div class="form-row justify-content-between">
                                    <div class="form-group col-md-6">
                                        <label for="">Email Address <span class="text-primary">*</span></label>
                                        <input name="email" type="text" class="form-control" id=""
                                               placeholder="Provide Email Address" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" value="<?php echo e($getparticularProfile->email); ?>" required>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="">Mobile Number <span class="text-primary">*</span></label>
                                        <input name="mobile" type="text" class="form-control" id="" placeholder="Provide Mobile Number" value="<?php echo e($getparticularProfile->mobile); ?>" pattern="^\d{10}$" readonly>
                                    </div>
                                </div>
                                
                                
                                <div class="form-row justify-content-between">
                                        <div class="form-group col-md-6">
                                            <label for="createInputState">State <span class="text-primary">*</span></label>
                                                <select name="state" id="stateId" class="selectpicker form-control " title="Choose..." data-live-search="true" onchange="getCity();" required>
                                                    <option value="">Choose State</option>
                                                    <?php $__currentLoopData = $stateList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($state->id); ?>" <?php if($state->id===$getparticularProfile->stateID): ?> <?php  echo 'selected'; ?> <?php endif; ?>" ><?php echo e($state->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
                                                </select>
                                        </div>
                                        
                                        <div class="form-group col-md-6">
                                            <div id="cityNew">
                                            <label for="createInputState">City <span class="text-primary">*</span></label>
                                               <select name="city" id="city" class="form-control " title="Choose..." data-live-search="true" required>
                                                
                                                <?php $__currentLoopData = $cityList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  
                                                <option value="<?php echo e($city->id); ?>" <?php if($city->id===$getparticularProfile->cityId ): ?> <?php  echo 'selected'; ?> <?php endif; ?>" ><?php echo e($city->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
                                                </select>
                                                </div>
                                        </div>
                                </div>
                                
                                
                                   
                                <div class="form-row justify-content-between">
                                    
                                    <div class="form-group col-md-6">
                                         <label for="createInputState">FTO Name <span class="text-primary"></span></label>
                                           
                                            <?php if($getparticularProfile->ftoId===null || $getparticularProfile->ftoId===0): ?>
                                            <select name="ftoId" class="selectpicker form-control " id="ftoId" title="Choose..." data-live-search="true" >
                                                <option value="">Select FTO</option>
                                                <?php $__currentLoopData = $FTOList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$FTOsList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($FTOsList->id); ?>" ><?php echo e($FTOsList->FTOName); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php else: ?>
                                           
                                            <select name="ftoId" class="selectpicker form-control " id="ftoId" title="Choose..." data-live-search="true" >
                                                <?php $__currentLoopData = $FTOList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$FTOsList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="">Select FTO</option>
                                                <option value="<?php echo e($FTOsList->id); ?>" <?php if($FTOsList->id==$getparticularProfile->ftoId): ?> <?php  echo 'selected'; ?> <?php endif; ?>" ><?php echo e($FTOsList->FTOName); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                         <?php endif; ?>
                                          
                                    </div>
                                    
                                    
                                    <div class="form-group col-md-6">
                                        
                                    </div>
                                </div>
                                
                                
                                
                                
                                <div class="form-row justify-content-between">
                                    <?php $allProfession=explode(",",$getparticularProfile->proffession); ?>
                                    <div class="form-group col-md-6">
                                        <label for="createInputProfession">Profession <span class="text-primary">*</span></label>
                                                
                                        <select name="profession[]" class="selectpicker form-control " title="Choose..." data-live-search="true" multiple required>
                                            
                                            <?php $__currentLoopData = $professionList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$professionsList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($professionsList->id); ?>" <?php  if (in_array($professionsList->id, $allProfession)){  echo "selected";} ?> ><?php echo e($professionsList->profession); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    
                                    
                                    <div class="form-group col-md-6">
                                        <label for="">Gender <span class="text-primary">*</span></label>
                                        <select name="gender" class="form-control " required>
                                            <option value="0" <?php if($getparticularProfile->gender==0): ?> <?php echo e('selected'); ?> <?php endif; ?>  >Male</option>
                                            <option value="1" <?php if($getparticularProfile->gender==1): ?> <?php echo e('selected'); ?> <?php endif; ?>  >Female</option>
                                            <option value="2" <?php if($getparticularProfile->gender==2): ?> <?php echo e('selected'); ?> <?php endif; ?>  >Other</option>
                                        </select>
                                    </div>
                                </div>
                                
                                
                                
                            
                                <div class="form-row justify-content-between">
                                    <div class="form-group col-md-6">
                                        <label for="createInputProfession">Pin Code<span class="text-primary">*</span></label>
                                        <input name="pincode" type="text" class="form-control" placeholder="Enter Pin Code" value="<?php echo e($getparticularProfile->pincode); ?>" pattern="^\d{6}$" required>
                                    </div>
                                    
                                    
                                    <div class="form-group col-md-6">
                                        
                                        <label for="createInputProfession">OAN Number </label>
                                                
                                        <input name="oannumber" type="text" class="form-control" value="<?php echo e($getparticularProfile->oannumber); ?>" placeholder="OAN Number" >
                                    </div>
                                </div>
                                
                                <div class="form-row justify-content-between">
                                        <div class="form-group col-md-6">
                                            <label for="createInputProfession">Provide Id Of <span class="text-primary">*</span></label>
                                                    
                                            <select name="proofidof" class="form-control " title="Choose..." data-live-search="true" required onchange="checkDoc(this.value)">
                                                <option value="0" <?php if($getparticularProfile->proofidof==0): ?> <?php echo e('selected'); ?> <?php endif; ?>  >Aadhar</option>
                                                <option value="1" <?php if($getparticularProfile->proofidof==1): ?> <?php echo e('selected'); ?> <?php endif; ?>  >Passport</option>
                                            </select>
                                        </div>
                                        
                                        <!--style="display: none;"-->
                                        <div class="form-group col-md-6"  id="numberInput">
                                            <label for="">Provide ID Number<span class="text-primary">*</span></label>
                                            <input name="proffId" type="text" class="form-control" id="proffId" value="<?php echo e($getparticularProfile->proffId); ?>"  required>
                                        </div>
                                </div>
                                
                                <div class="form-row justify-content-between">
                                        <div class="form-group col-md-6">
                                            <label for="createInputDescription">Experience in Brief</label>
                                            <textarea name="profession_desc" class="form-control" id="createInputDescription" placeholder="Provide Brief Description" rows="2" value="<?php echo e($getparticularProfile->experience); ?>"><?php echo e($getparticularProfile->experience); ?></textarea>
                                        </div>
                                        
                                        <div class="form-group col-md-6"  id="numberInput">
                                            <label for="">Profile Photo</label>
                                            <br>
                                            
                                            <?php
        									if(!empty($getparticularProfile->profilePhoto))
        									{
        									?>
        									    <img src="<?php echo env('APP_URL');?>public/asset/Pilot/Image/<?php echo e($getparticularProfile->profilePhoto); ?>" height="70" width="70">
        								        
        									<?php
        									}
        									else
        									{
        									?>
        									      <img src="<?php echo env('APP_URL');?>public/asset/no-image-available.png" height="70" width="70">
        									<?php
        									}
        									?>
        									<input name="unlinkprofilePhoto" type="text" class="form-control" accept=".png, .jpg, .jpeg" value="<?php if(!empty($getparticularProfile->profilePhoto))
            									{
            									?><?php echo e($getparticularProfile->profilePhoto); ?>

            									<?php 
            									} 
            									?>" hidden>
                                            <input name="profilePhoto" type="file" class="form-control" accept=".png, .jpg, .jpeg" >
                                            
                                        </div>
                                </div>
                                
                                <!--<div class="form-group ">-->
                                <!--    <label for="createInputDescription">Experience in Brief</label>-->
                                <!--    <textarea name="profession_desc" class="form-control" id="createInputDescription" placeholder="Provide Brief Description" rows="2" value="<?php echo e($getparticularProfile->experience); ?>"><?php echo e($getparticularProfile->experience); ?></textarea>-->
                                <!--</div>-->
                            
                                </br>Thanks for Registering on RPA PILOT . We all know  that our Country is passing through a Crisis Due to COVID-19 and Central and State Government may need volunteers to fly Drones  for various purpose . If you want to provide service to the Nation please  
                                </br>
                                    <?php if($getparticularProfile->covid19==0): ?>
                                        <input type="checkbox" name="chbox" id="chbox" checked>Tick here
                                    <?php else: ?>
                                        <input type="checkbox" name="chbox" id="chbox" >Tick here
                                    <?php endif; ?>
                                <br>
                                
                            <button type="submit" class="btn btn-primary" >Update</button>

                        </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
				<!-- Export Datatable End -->
			</div>
		
</div>
</div>

<script>
    
    function getCity(){
            var url=APP_URL+'/getcityforupdate';
            let stateId = $('#stateId').val();
            // alert(stateId);
            if(stateId==null || stateId=='')
            {
                alert("Select City");
                return false;
            }
            
            $.ajax({
                url:url,
                type: 'post',
                dataType: 'html',
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    'stateId': stateId
                },
                
                
                success: function (response) {
                    
                    $('#cityNew').empty();
                    $('#cityNew').append(response);
                    $('#cityNew').show();
                }
                
                
                
                
            });
    }
    
    
</script>

<script>
    function checkDoc(valueSelected)
    {
        if(valueSelected=='0')
        {
            $("#numberInput").show();
            $("#proffId").attr("placeholder","Provide Addhar Card Number");
        }
        else
        {
            $("#numberInput").show();
            $("#proffId").attr("placeholder","Provide Passport Number");
        }
    }
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('pilot.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rpapilot/public_html/rpa/resources/views/pilot/profile/profile.blade.php ENDPATH**/ ?>