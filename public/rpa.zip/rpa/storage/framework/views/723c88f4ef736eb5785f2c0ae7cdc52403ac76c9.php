<?php $__env->startSection('content'); ?>
<?php $CommonService = app('App\Http\Controllers\Common\CommonController'); ?>
<?php  ?>
<div class="main-container">
		<div class="pd-ltr-20 customscroll customscroll-10-p height-100-p xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Pilots</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo e(route('dashadmin')); ?>">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Pilots List</li>
								</ol>
							</nav>
						</div>
						<div class="col-md-6 col-sm-12 text-right">

						</div>
					</div>
				</div>
			
				<!-- Export Datatable start -->
				<div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
					<div class="clearfix mb-20">
						<div class="pull-left">
							<h5 class="text-blue">Pilots List</h5>
						</div>
					</div>
					<div class="row table-responsive ">
					    <?php if(session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session()->get('success')); ?>

                            </div>
                        <?php endif; ?>
                        
                        
                        
                        <?php if(session()->has('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session()->get('error')); ?>

                            </div>
                        <?php endif; ?>
                        
						<table class="table table-striped" id="pageDataTable" role="grid" aria-describedby="DataTables_Table_0_info">
							<thead>
								<tr>
								    <?php
								    $count=0;
								    ?>
									<!--<th class="table-plus datatable-nosort"></th>-->
									<th>Sn.</th>
									<th>Name</th>
									<th>Mobile</th>
									<!--<th>Category</th>-->
									<th>Gender</th>
									<th>Email</th>
									<th>State</th>
									<th>City</th>
									<th>FTO Approved</th>
									<th>Status</th>
									<!--<th>Action</th>-->
								
								</tr>
							</thead>
							<tbody>
							    
							    <?php if(count($allPilots) > 0): ?>
							    <?php
							   
                                          foreach($allPilots as $getallPilots )
                                          {
                                ?>
								<tr>
								    <td><?php echo e(++$count); ?></td>
									<td><?php echo e($getallPilots->firstName); ?> <?php echo e($getallPilots->middleName); ?> <?php echo e($getallPilots->lastName); ?></td>
									<td><?php echo e($getallPilots->mobile); ?></td>
									<!--<td><?php echo e($getallPilots->category); ?></td>-->
									<td>
									    <?php if($getallPilots->gender == 0): ?>
									    <?php echo e('Male'); ?>

									    <?php elseif($getallPilots->gender == 1): ?>
									    <?php echo e('Female'); ?>

									    <?php else: ?>
									    <?php echo e('Other'); ?>

									    <?php endif; ?>
									    </td>
									<td><?php echo e($getallPilots->email); ?></td>
									<td><?php $state=$CommonService->getPerticularStateById($getallPilots->stateID);?>   <?php echo e($state[0]->name); ?></td>
									<td><?php $city=$CommonService->getPerticularCityById($getallPilots->cityId);?>  <?php echo e($city[0]->name); ?></td>
									<td>
							        <?php if($getallPilots->ftoApproved == 1): ?>
							        <font color="green"><?php echo e('Approved'); ?></font>
							        <?php else: ?>
							        <font color="red"><?php echo e('Not Approved'); ?></font>
							        <?php endif; ?>
							        </td>
							        
							        <td>
								        <?php if($getallPilots->adminApproved == 1): ?>
								            <a class="btn btn-success" href="<?php echo e(route('admpilotdisapprove',array('pilotId'=>$getallPilots->pilotIdFInal,'approvalVal'=>$getallPilots->adminApproved))); ?>" title="Approved" role="button" >
									            <i class="fa fa-thumbs-up"></i>
								            </a>
								            
								        <?php else: ?>
								            <a class="btn btn-danger" href="<?php echo e(route('admpilotapprove',array('pilotId'=>$getallPilots->pilotIdFInal,'approvalVal'=>$getallPilots->adminApproved))); ?>" title="DisApproved" role="button" >
									            <i class="fa fa-thumbs-down"></i>
								            </a>
                                        <?php endif; ?>
								    </td>
								</tr>
								<?php
                                          }
                                          ?>
								
                                 


							</tbody>
						</table>
					    
					    <?php endif; ?>
					</div>
				</div>
				<!-- Export Datatable End -->
			</div>
		
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rpapilot/public_html/rpa/resources/views/admin/pilots/pilots.blade.php ENDPATH**/ ?>