
<style>

    .navbar-light .navbar-nav .nav-link {
        color: #111 !important;
        font-size: 16px;
        font-weight: 450;
    }
    .navbar-nav,
    .mr-auto {
        flex: 1;
        margin: auto !important;
        display: flex;
        justify-content: space-between;
    }
    
    
    
    .button {
  
  -webkit-border-radius: 10px;
  border-radius: 10px;
  border: none;
  cursor: pointer;
  display: inline-block;
  font-family: Arial;
  font-size: 20px;
  padding: 5px 10px;
  text-align: center;
  text-decoration: none;
  -webkit-animation: glowing 1500ms infinite;
  -moz-animation: glowing 1500ms infinite;
  -o-animation: glowing 1500ms infinite;
  animation: glowing 1500ms infinite;
}
@-webkit-keyframes glowing {
  0% { background-color: #FF8923; -webkit-box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF8923; -webkit-box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #FF8923; -webkit-box-shadow: 0 0 3px #B20000; }
}

@-moz-keyframes glowing {
  0% { background-color: #FF8923; -moz-box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF8923; -moz-box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #FF8923; -moz-box-shadow: 0 0 3px #B20000; }
}

@-o-keyframes glowing {
  0% { background-color: #FF8923; box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF8923; box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #FF8923; box-shadow: 0 0 3px #B20000; }
}

@keyframes  glowing {
  0% { background-color: #FF8923; box-shadow: 0 0 3px #B20000; }
  50% { background-color: #FF8923; box-shadow: 0 0 40px #FF0000; }
  100% { background-color: #FF8923; box-shadow: 0 0 3px #B20000; }
}



</style>


<nav class="navbar navbar-expand-md navbar-light nav-fill nav-justified">
    <div class="container" style="max-width: 1400px;">
    <a href="<?php echo e(url('index')); ?>" class="navbar-brand order-1 order-md-1 b-sidebar-trigger">
        <img src="<?php echo e(asset('website/images/rpapilot_logo.png')); ?>" style="width: 80px;">
    </a>


    <div class="collapse navbar-collapse order-3 order-md-2 " id="navbarNav">
        <ul class="navbar-nav  justify-content-between ">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button"
                   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Explore
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item  border-bottom" href="<?php echo e(url('about')); ?>">About</a>
                    <a class="dropdown-item  border-bottom" href="<?php echo e(url('droneapplication')); ?>">Drone Application</a>
                    <a class="dropdown-item  border-bottom" href="<?php echo e(url('library')); ?>">Library Membership</a>
                    <a class="dropdown-item  border-bottom" href="<?php echo e(url('advisoryboard')); ?>">Advisory Board</a>
                    <a class="dropdown-item" href="<?php echo e(url('ftoinstrctorlistweb')); ?>">Instructor List</a>
                </div>
            </li>

            <li class="nav-item">
                <!--<a class="nav-link " href="<?php echo e(url('courses.search')); ?>">Courses</a>-->
                <a class="nav-link " href="<?php echo e(url('webcoursessearch')); ?>">Courses</a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle " href="#" id="navbarDropdownMenuLink" role="button"
                   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Pilots
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item  border-bottom " href="<?php echo e(route('webpilotsearch')); ?>">Pilot Search</a>
                    <a class="dropdown-item  border-bottom " href="<?php echo e(route('pilotregform')); ?>">Pilot Registration</a>
                    <a class="dropdown-item border-bottom" href="<?php echo e(route('uaopverification')); ?>">Verify a Pilot</a> 
                    <a class="dropdown-item border-bottom" href="<?php echo e(url('hirepilot')); ?>">Hire Pilot</a>
                    <a class="dropdown-item" href="<?php echo e(route('pilot')); ?>" target="_blank">Login</a>
                </div>
            </li>

            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle <?php if(Request::is('fto/*')): ?> font-weight-bold text-primary <?php endif; ?>" href="#" id="navbarDropdownMenuLink" role="button"
                   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    FTO
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item  border-bottom " href="<?php echo e(route('webftosearch')); ?>" >Search</a>
                    <a class="dropdown-item  border-bottom "  href="<?php echo e(route('ftoregform')); ?>" >Register</a>
                    <a class="dropdown-item   "  href="<?php echo e(route('fto')); ?>" target="_blank">Login</a>
                </div>
            </li>
            
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle " href="#" id="navbarDropdownMenuLink" role="button"
                   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Student
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item" href="<?php echo e(route('student')); ?>" target="_blank">Login</a>
                </div>
            </li>

            <!--<li class="nav-item">-->
            <!--    <a class="nav-link" href="<?php echo e(url('comingsoon')); ?>">NPNT</a>-->
            <!--</li>-->

            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button"
                   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Media & News
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item border-bottom" href="<?php echo e(url('photogallery')); ?>">Photo Gallery</a>
                    <a class="dropdown-item border-bottom" href="<?php echo e(url('videogallery')); ?>">Video Gallery</a>
                    <!--<a class="dropdown-item border-bottom" href="<?php echo e(url('comingsoon')); ?>">Pilot Videos</a>-->
                    <a class="dropdown-item border-bottom" href="<?php echo e(url('eventsearch')); ?>">Event Search</a>
                    <!--<a class="dropdown-item border-bottom" href="">Register Your Event</a>-->
                    <a class="dropdown-item border-bottom" href="<?php echo e(url('comingsoon')); ?>">RPA Pilot Blog</a>
                    <a class="dropdown-item border-bottom" href="<?php echo e(url('govtpolicies')); ?>">Indian Goverment Policies</a>
                    <a class="dropdown-item border-bottom" href="<?php echo e(url('comingsoon')); ?>">DGCA Press Release</a>
                    <a class="dropdown-item border-bottom" href="<?php echo e(url('comingsoon')); ?>">Drone News Feed</a>
                    <a class="dropdown-item" href="<?php echo e(url('comingsoon')); ?>">Webinars</a>
                </div>
            </li>
            
            <!--<li class="nav-item">-->
            <!--    <a class="nav-link" href="<?php echo e(url('comingsoon')); ?>">Store</a>-->
            <!--</li>-->
        </ul>
    </div>


     <div class="nav-item order-2 order-md-3">
        <form action="" method="get" id="rpacartForm">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="cart" id="InputRpaCart">
        </form>
        <span class="px-3">
        <!--<span id="rpacart"  class="cursor-pointer" onclick="event.preventDefault(); document.getElementById('rpacartForm').submit();">-->
        <!--            <span class="badge badge-pill badge-primary counting">0</span>-->
        <!--            <i class="material-icons-outlined px-2"> shopping_cart</i>-->
        <!--    </span>-->
            </span>
 
        We are recognised by
         <img src="<?php echo e(asset('website/Start_Up_India_Logo.png')); ?>" style="max-width: 100%;     height: 45px;    width: 103px;     margin-left: 68px;
">


        <span class="navbar-toggler" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav"
              aria-expanded="false" aria-label="Toggle navigation">
            <i class="material-icons">keyboard_arrow_down</i>
        </span>
    </div>
    </div>
    
</nav>
<?php /**PATH /home/sumagoinfotech/public_html/rpa/resources/views/website/layouts/header.blade.php ENDPATH**/ ?>