<!DOCTYPE html>
<html>
<body>
<?php
	foreach($getCertificate as $getCertificate )
      {
?>
<h1><?php echo e($getCertificate->firstName); ?> </h1> You are Genius.

<?php
      }
?>
                                          
</body>
</html><?php /**PATH /home/sumagoinfotech/public_html/rpa/resources/views/fto/certificate/certificate.blade.php ENDPATH**/ ?>