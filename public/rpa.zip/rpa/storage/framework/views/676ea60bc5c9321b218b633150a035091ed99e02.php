<!--  <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.1/jquery.min.js">
  </script> -->
<script src="http://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.2/js/toastr.min.js">  </script> 
<script>
    <?php if(count($errors->all()) > 0): ?>
    <?php for($i=0;$i<sizeof($errors->all());$i++) { ?>
    toastr.error('<?php echo e($errors->all()[$i]); ?>');
    <?php }?>
   
    <?php endif; ?>
    <?php if(session('success')): ?>
    toastr.success('<?php echo e(session('success')); ?>');
    <?php endif; ?>
    <?php if(session('error')): ?>
    toastr.error('<?php echo e(session('error')); ?>');
    <?php endif; ?>
</script><?php /**PATH C:\xampp\htdocs\rpa\resources\views/fto/layout/toast.blade.php ENDPATH**/ ?>