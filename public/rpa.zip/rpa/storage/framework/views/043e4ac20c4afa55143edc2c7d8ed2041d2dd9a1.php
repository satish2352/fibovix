<?php $__env->startSection('title'); ?>
    All Instructor List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('website.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('website.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<?php $FTOInstructorService = app('App\Http\Service\Admin\FTO\FTOInstructorService'); ?>
<?php $CommonService = app('App\Http\Service\Common\CommonService'); ?>

<style type="text/css">
  .table-striped tbody tr:nth-of-type(2n+1) {

    background-color: #FEAD69;

}
</style>
<div class="row text-center justify-content-center" style="margin-top: 15px;">
      <div class="col-md-12">
          <h1 class=" text-uppercase text-primary">FTO Instructor List</h1>

      </div>
  </div>
<div class="container my-5">
   <div class="card box-shadow-1 mb-2">
    <div class="card-body text-center">
        <div class="row">
                <table class="table table-striped" id="pageDataTable" role="grid" aria-describedby="DataTables_Table_0_info" style="border: 1px solid;">
                     	    <thead>
								<tr>
								    <th>Sr.No.</th>
								    <th>Trainer Name</th>
								    <th>FTO Represented</th>
									
								</tr>
							</thead>
							<tbody>
							    <?php $__currentLoopData = $ftoList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$FTOsList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="width:20px"><?php echo e($key+1); ?></td>
                                     <td>
                                         <?php $allInstructorList=$FTOInstructorService->getAllInstructorListUderFTO($FTOsList->id); ?>
                                        <?php if(count($allInstructorList)): ?>
                                            <?php $__currentLoopData = $allInstructorList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(count($allInstructorList)>1): ?>
                                                    <?php echo e($key+1); ?>

                                                <?php endif; ?>
                                                <?php echo e($value->instructorName); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <span class="text-danger">No Instructor Present</span>
                                         <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </td>
                                    <td>
                                        <?php //$ftoDetails=$CommonService->getFTODetails($FTOsList->id);?>
                                    <?php echo e($FTOsList->FTOName); ?>

                                    </td>
                                   
                                    
                                </tr>
                                
                               
                                

							</tbody>
						</table>
					</div>
				</div>
			</div>
    </div>
 
   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rpapilot/public_html/rpa/resources/views/website/fto/instructor.blade.php ENDPATH**/ ?>