<?php $__env->startSection('content'); ?>

<div class="main-container">
		<div class="pd-ltr-20 customscroll customscroll-10-p height-100-p xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>TPM</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo e(route('dashfto')); ?>">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">TPM List</li>
								</ol>
							</nav>
						</div>
						<div class="col-md-6 col-sm-12 text-right">
							<div class="dropdown">
								<a href="#TPMModal" class="btn btn-primary" role="button" data-toggle="modal" data-target="#TPMModal">
								    Upload TPM
								</a>
							</div>
						</div>
					</div>
				</div>
			
				<!-- Export Datatable start -->
				<div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
					<div class="clearfix mb-20">
						<div class="pull-left">
							<h5 class="text-blue">TPM List</h5>
						</div>
					</div>
					<?php
					//$pilotId=session()->get('pilotId');
					
					?>
					<div class="row table-responsive ">
					    <?php if(session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session()->get('success')); ?>

                            </div>
                        <?php endif; ?>
                        
                        
                        
                        <?php if(session()->has('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session()->get('error')); ?>

                            </div>
                        <?php endif; ?>
						<table class="table table-striped" id="pageDataTable" role="grid" aria-describedby="DataTables_Table_0_info">
							<thead>
								<tr>
								    <?php
								    $count=0;
								    ?>
									<th>Sn.</th>
									<th>title</th>
									<th>content</th>
									<th>PDF</th>
									<th>Created On</th>
									<th>Admin Status</th>
									<th>Show / Hide</th>
								
								</tr>
							</thead>
							<tbody>
							    
							    <?php if(count($allTPM) > 0): ?>
							    <?php
							    $cDate = date('d F Y');
									
                                    foreach($allTPM as $getallTPM )
                                      {
									    
                                ?>
								<tr>
								    <td><?php echo e(++$count); ?></td>
									<td><?php echo e($getallTPM->title); ?></td>
									<td><?php echo e($getallTPM->content); ?></td>
									<?php
									if($getallTPM->pdf)
									{
									?>
									<td>
									    
									    <a href="public/asset/TPM/Pdf/<?php echo e($getallTPM->pdf); ?>" class="btn btn-success dropdown" dropdown height="100" width="100" target="_blank">
									        <i class="fa fa-download"></i>
									    </a>
									</td>
									<?php
									}
									else
									{
									?>
									  <td>
									      <img src="public/asset/no-pdf.png" height="100" width="100">
									  </td>
									<?php
									}
									?>
									
									<td><?php echo e($getallTPM->createdOn); ?></td>
									<td>
								        <?php if($getallTPM->adminStatus == "1"): ?>
								            <span class="text-success">Approved</span>
								        <?php else: ?>
								            <span class="text-danger">DisApproved</span>
                                        <?php endif; ?>
								    </td>
									
									<td>
								        <?php if($getallTPM->status == "1"): ?>
								            <a class="btn btn-success" href="<?php echo e(route('tpmshowhidebyfto',array('id'=>$getallTPM->id,'approvalVal'=>$getallTPM->status))); ?>" role="button" >
									            <i class="fa fa-thumbs-up"></i>
								            </a>
								            
								        <?php else: ?>
								            <a class="btn btn-danger" href="<?php echo e(route('tpmshowhidebyfto',array('id'=>$getallTPM->id,'approvalVal'=>$getallTPM->status))); ?>" role="button" >
									            <i class="fa fa-thumbs-down"></i>
								            </a>
                                        <?php endif; ?>
								    </td>
								
								</tr>
								<?php
                                          }
                                          ?>
								
                                  <?php endif; ?>



							</tbody>
						</table>
					</div>
				</div>
				<!-- Export Datatable End -->
			</div>
		
</div>
</div>
<?php $__env->stopSection(); ?>









<!-- Modal -->
<div class="modal fade" id="TPMModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button> -->
        <h4 class="modal-title" id="myModalLabel"><center>Upload TPM</center></h4>
      </div>
      <div class="modal-body">
        	<!--<form method="post" enctype="multipart/form-data">-->
        	    <form action="<?php echo e(route('saveftotpm')); ?>" method="POST" enctype="multipart/form-data">
					    <?php echo csrf_field(); ?>
					    
						
					    <div class="form-group row">
							<label class="col-sm-12 col-md-1 col-form-label"><span style="color: red">*</span></label>
							<div class="col-sm-12 col-md-11">
								<input class="form-control" type="text" name="adsTitle" id="" placeholder="Enter TPM Title" required="" >
								
							</div>
						</div>
						
						<div class="form-group row">
							<label class="col-sm-12 col-md-1 col-form-label"><span style="color: red">*</span></label>
							<div class="col-sm-12 col-md-11">
							    <textarea class="form-control" name="adsContent" placeholder="TPM Content" required=""></textarea>
							</div>
						</div>
						
						<div class="form-group row">
							<label class="col-sm-12 col-md-1 col-form-label"><span style="color: red">*</span>PDF</label>
							<div class="col-sm-12 col-md-11">
								<input class="form-control" type="file" name="pdf" accept=".pdf" required="">
							</div>
						</div>
						
						
					
					
				        <div class="modal-footer">
                           <button class="btn btn-success" type="submit" >
		                        Submit
                           </button>
          
                           <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        </div>	
						
 </form>
      </div>
      
    </div>
  </div>
</div>
<?php echo $__env->make('fto.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sumagoinfotech/public_html/rpa/resources/views/fto/tpm/tpm.blade.php ENDPATH**/ ?>