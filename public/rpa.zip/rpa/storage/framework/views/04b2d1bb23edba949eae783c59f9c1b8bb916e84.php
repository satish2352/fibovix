<?php $__env->startSection('content'); ?>
<?php $CommonService = app('App\Http\Controllers\Common\CommonController'); ?>
<div class="main-container">
<div class="pd-ltr-20 customscroll customscroll-10-p height-100-p xs-pd-20-10">
   <div class="min-height-200px">
      <div class="page-header">
         <div class="row">
            <div class="col-md-6 col-sm-12">
               <div class="title">
                  <h4>FTOs</h4>
               </div>
               <nav aria-label="breadcrumb" role="navigation">
                  <ol class="breadcrumb">
                     <li class="breadcrumb-item"><a href="<?php echo e(route('dashadmin')); ?>">Home</a></li>
                     <li class="breadcrumb-item active" aria-current="page">Pilots Search</li>
                  </ol>
               </nav>
            </div>
            <div class="col-md-6 col-sm-12 text-right">
            </div>
         </div>
      </div>
      <!-- Export Datatable start -->
      <div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
         <div class="clearfix mb-20">
            <div class="pull-left">
               <h5 class="text-blue">Pilots Search</h5>
            </div>
         </div>
         <div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
            <div class="clearfix">
               <!--<div class="pull-left">-->
               <!--	<h4 class="text-blue">Select 2</h4>-->
               <!--	<p class="mb-30 font-14">Select2 for custom search and select</p>-->
               <!--</div>-->
            </div>
            <form>
               <div id="tableAjax">
                  <div class="row">
                      <?php //dd($allFTO); ?>
                     <div class="form-group col-sm-4" >
                        <label>State</label>
                        <select name="fto" id="ftoId" class="custom-select col-12" onchange="getResultByfto(this.value);" title="Choose..." data-live-search="true" required>
                           <option value="">Choose FTO</option>
                           <?php $__currentLoopData = $allFTO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allFTOs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($allFTOs->id); ?>" ><?php echo e($allFTOs->firstName); ?> <?php echo e($allFTOs->middleName); ?> <?php echo e($allFTOs->lastName); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
                        </select>
                     </div>
                     <div class="form-group col-sm-4">
                         <label>State</label>
                        <select name="state" id="stateId" class="custom-select col-12" onchange="getResultByState(this.value);" title="Choose..." data-live-search="true" required>
                           <option value="">Choose State</option>
                           <?php $__currentLoopData = $stateList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($state->id); ?>" ><?php echo e($state->name); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
                        </select>
                     </div>
                     <div class="form-group col-sm-4">
                     </div>
                  </div>
            </form>
            <div class="row table-responsive ">
            <table class="table table-striped" id="pageDataTable" role="grid" aria-describedby="DataTables_Table_0_info">
            <thead>
            <tr>
            <?php
               $count=0;
               ?>
            <!--<th class="table-plus datatable-nosort"></th>-->
            <th>Sn.</th>
            <th>Name</th>
            <th>Mobile</th>
            <th>Category</th>
            <th>Email</th>
            <th>State</th>
            <th>City</th>
            <th>FTO Approved</th>
            <th>Status</th>
            <th>Action</th>
            <!--<th>Entry By</th>-->
            <!--<th>Aadhar No.</th>-->
            <!--<th>Category</th>-->
            <!--<th>UAOP Number</th>-->
            <!--<th>UAOP Validity</th>-->
            <!--<th>UIN Number</th>-->
            <!--<th>UIN Validity</th>-->
            <!--<th>NPNT</th>-->
            <!--<th>FTO</th>-->
            <!--<th>Drone Serial Number</th>-->
            <!--<th>Proffession</th>-->
            <!--<th>Experience</th>-->
            <!--<th>Passport</th>-->
            <!--<th>Driving Licence</th>-->
            <!--<th>Qualification</th>-->
            <!--<th>Passport Photo</th>-->
            <!--<th>Registration Date</th>-->
            </tr>
            </thead>
            <tbody>
            <?php if(count($allPilots) > 0): ?>
            <?php
               //dd($allPilots);
                                              foreach($allPilots as $getallPilots )
                                              {
                                    ?>
            <tr>
            <td><?php echo e(++$count); ?></td>
            <td><?php echo e($getallPilots->firstName); ?> <?php echo e($getallPilots->middleName); ?> <?php echo e($getallPilots->lastName); ?></td>
            <td><?php echo e($getallPilots->mobile); ?></td>
            <td><?php echo e($getallPilots->category); ?></td>
            <td><?php echo e($getallPilots->email); ?></td>
            <td><?php $state=$CommonService->getPerticularStateById($getallPilots->stateID);?>   <?php echo e($state[0]->name); ?></td>
			<td><?php $city=$CommonService->getPerticularCityById($getallPilots->cityId);?>  <?php echo e($city[0]->name); ?></td>
            <td>
            <?php if($getallPilots->ftoApproved == 1): ?>
            <font color="green"><?php echo e('FTO Approved'); ?></font>
            <?php else: ?>
            <font color="red"><?php echo e('FTO Not Approved'); ?></font>
            <?php endif; ?>
            </td>
            <td>
            <?php if($getallPilots->adminApproved == 1 && $getallPilots->ftoApproved == 1): ?>
            <a class="btn btn-success" href="<?php echo e(route('admpilotdisapprove',array('pilotId'=>$getallPilots->pilotIdFInal,'approvalVal'=>$getallPilots->adminApproved))); ?>" title="Approved" role="button" >
            <i class="fa fa-thumbs-up"></i>
            </a>
            <?php elseif($getallPilots->adminApproved == 0 && $getallPilots->ftoApproved == 1 ): ?>
            <a class="btn btn-danger" href="<?php echo e(route('admpilotapprove',array('pilotId'=>$getallPilots->pilotIdFInal,'approvalVal'=>$getallPilots->adminApproved))); ?>" title="DisApproved" role="button" >
            <i class="fa fa-thumbs-down"></i>
            </a>
            <?php elseif($getallPilots->ftoApproved == 0 ): ?>
            <font color="red"><?php echo e('Not Approved By FTO'); ?></font>
            <?php endif; ?>
            </td>
            <td>
            <a class="btn btn-primary" href="#" role="button" >
            View
            </a>
            </td>
            <!--<td>-->
            <!--       <?php if($getallPilots->entryBy == 0): ?>-->
            <!--               User-->
            <!--       <?php else: ?>-->
            <!--               Admin-->
            <!--                               <?php endif; ?>-->
            <!--   </td>-->
            <!--<td><?php echo e($getallPilots->adharNumber); ?></td>-->
            <!--<td><?php echo e($getallPilots->category); ?></td>-->
            <!--<td><?php echo e($getallPilots->uaopnumber); ?></td>-->
            <!--<td><?php echo e($getallPilots->uaopvalidity); ?></td>-->
            <!--<td><?php echo e($getallPilots->uinnumber); ?></td>-->
            <!--<td><?php echo e($getallPilots->uinvalidity); ?></td>-->
            <!--<td><?php echo e($getallPilots->npnt); ?></td>-->
            <!--<td><?php echo e($getallPilots->name); ?></td>-->
            <!--<td><?php echo e($getallPilots->droneSerialNumber); ?></td>-->
            <!--<td><?php echo e($getallPilots->proffession); ?></td>-->
            <!--<td><?php echo e($getallPilots->experience); ?></td>-->
            <!--<td><?php echo e($getallPilots->passport); ?></td>-->
            <!--<td><?php echo e($getallPilots->drivingLicence); ?></td>-->
            <!--<td><?php echo e($getallPilots->eduQualification); ?></td>-->
            <!--<td><?php echo e($getallPilots->passportPhoto); ?></td>-->
            <!--<td><?php echo e($getallPilots->createdAt); ?></td>-->
            </tr>
            <?php
               }
               ?>
            <?php endif; ?>
            </tbody>
            </table>
            </div>
            </div>
         </div>
         <!-- Export Datatable End -->
      </div>
   </div>
</div>
<script type="text/javascript">
   function getResultByState(stateId)
   {
     var ftoId=document.getElementById('ftoId').value;
     var url =APP_URL+'/'+'pilotsearchbystatecity';
     $('#tableAjax').empty();
     $.ajax({
               type: "post",
               url: url,
               data :{
                   "_token": "<?php echo e(csrf_token()); ?>",
                   'stateId':stateId,
                   'ftoId':ftoId,
               },
               success: function(newdata)
               {
                 $('#tableAjax').empty();
                 $('#tableAjax').append(newdata);
   
               }
   
             });
   }
</script>
<script type="text/javascript">
   function getResultByCity(cityId)
   {
     var ftoId=document.getElementById('ftoId').value;
     var stateId=document.getElementById('stateId').value;
     $('#tableAjax').empty();
     var url =APP_URL+'/'+'pilotsearchbystatecity';
     $.ajax({
               type: "post",
               url: url,
               data :{
                   "_token": "<?php echo e(csrf_token()); ?>",
                   'stateId':stateId,
                   'cityId':cityId,
                   'ftoId':ftoId,
               },
               success: function(newdata)
               {
                 $('#tableAjax').empty();
                 $('#tableAjax').append(newdata);
   
               }
   
             });
   }
</script>
<script>
    function getResultByfto(ftoId)
   {
     
     var stateId=document.getElementById('stateId').value;
     var url =APP_URL+'/'+'pilotsearchbystatecity';
     $('#tableAjax').empty();
     $.ajax({
               type: "post",
               url: url,
               data :{
                   "_token": "<?php echo e(csrf_token()); ?>",
                   'stateId':stateId,
                   'ftoId':ftoId,
               },
               success: function(newdata)
               {
                 $('#tableAjax').empty();
                 $('#tableAjax').append(newdata);
   
               }
   
             });
   }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rpapilot/public_html/rpa/resources/views/admin/pilots/pilotsearch.blade.php ENDPATH**/ ?>