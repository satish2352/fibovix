<?php $__env->startSection('title'); ?>
    All Instructor List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('website.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('website.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<?php $FTOInstructorService = app('App\Http\Service\Admin\FTO\FTOInstructorService'); ?>
<?php $CommonService = app('App\Http\Service\Common\CommonService'); ?>

<style type="text/css">
  .table-striped tbody tr:nth-of-type(2n+1) {

    background-color: #FEAD69;

}
</style>
<div class="row text-center justify-content-center" style="margin-top: 15px;">
      <div class="col-md-12">
          <h1 class=" text-uppercase text-primary">FTO Instructor List</h1>

      </div>
  </div>
<div class="container my-5">
   <div class="card box-shadow-1 mb-2">
    <div class="card-body text-center">
        <div class="row">
					     <?php //dd($allState); ?>                       
                <table class="table table-striped" id="pageDataTable" role="grid" aria-describedby="DataTables_Table_0_info" style="border: 1px solid;">
                     	    <thead>
								<tr>
								    <th>Sr.No.</th>
								    <th>FTO Name</th>
									<th>Instructor Name</th>
								    <th></th>
								    <th></th>
								</tr>
							</thead>
							<tbody>
							    <?php $__currentLoopData = $ftoList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$FTOsList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php $ftoDetails=$CommonService->getFTODetails($FTOsList->id);?>  <?php echo e($ftoDetails[0]->firstName); ?>  <?php echo e($ftoDetails[0]->middleName); ?>  <?php echo e($ftoDetails[0]->lastName); ?></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                
                                <?php $allInstructorList=$FTOInstructorService->getAllInstructorListUderFTO($FTOsList->id);
                                      //dd($allInstructorList);?>
                                <?php if(count($allInstructorList)): ?>
                                <?php $__currentLoopData = $allInstructorList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    
                                    <td></td>
                                    <td align="right"><?php echo e($key+1); ?></td>
                                    <td><?php echo e($value->instructorName); ?></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <tr>
                                <td colspan="5" align="center"><span class="text-danger">No Instructor Present</span></td>
                              </tr>
                                <?php endif; ?>
                                
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							    
                     	    
                     	    
                     	    
                     	    
						
							    
							    
							 <!--   <tr>-->
							        
								<!--    <td>1</td>-->
								<!--	<td>Maharastra</td>-->
								<!--	<td>-->
								<!--	   	<button class="btn btn-danger" role="button">-->
        <!--								    <i class="fa fa-thumbs-down"></i>-->
        <!--								</button>-->
        <!--                        	</td>-->
								    
								<!--	<td>-->
								<!--	    <a class="btn btn-primary" href="#" role="button" >-->
								<!--	        View-->
								<!--        </a>-->
								<!--    </td>-->
								<!--</tr> -->
																


							</tbody>
						</table>
					</div>
				</div>
			</div>
    </div>
 
            



<!-- Modal -->
<div class="modal fade" id="stateModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button> -->
        <h4 class="modal-title" id="myModalLabel"><center>Add Instructor Name</center></h4>
      </div>
      <div class="modal-body">
        	    <form>

                    <div class="form-group row">
							<label class="col-sm-12 col-md-1 col-form-label"><span style="color: red">*</span></label>
							<div class="col-sm-12 col-md-11">
							    <select class="form-control" name="ftoId" id="ftoId" required="">
							        <option value="">Select FTO</option>
							         <?php $__currentLoopData = $ftoList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$FTOsList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							        <option value="<?php echo e($FTOsList->id); ?>"<?php if($allStateForEdit): ?>  <?php if($FTOsList->id==$allStateForEdit[0]->underFTO): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?> ><?php echo e($FTOsList->firstName); ?> <?php echo e($FTOsList->middleName); ?> <?php echo e($FTOsList->lastName); ?></option>
							        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							    </select>
							</div>
					</div>
					<div class="form-group row">
							<label class="col-sm-12 col-md-1 col-form-label"><span style="color: red">*</span></label>
							<div class="col-sm-12 col-md-11">
							    <input class="form-control" type="text" name="" id="ftoInstructorId" placeholder="" value="<?php if($allStateForEdit): ?><?php echo e($allStateForEdit[0]->id); ?><?php endif; ?>" required="" hidden>
								<input class="form-control" type="text" name="" id="ftoInstructorName" placeholder="Enter Instructor Name" value="<?php if($allStateForEdit): ?><?php echo e($allStateForEdit[0]->instructorName); ?><?php endif; ?>" required="" >
							</div>
					</div>
					

						<!--<div class="modal-footer">-->
      <!--                     <a class="btn btn-success" onclick="saveState();"> Save </a>-->
		    <!--               <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>-->
      <!--                </div>-->
                      
                      
                      <div class="modal-footer">
                           <button class="btn btn-success" type="submit" name="addCourse" onclick="saveState();">
		                        Save
                           </button>
          
                           <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                      </div>
                      
                      
                 </form>
      </div>
      
    </div>
  </div>
</div>



	
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script type="text/javascript">
    var APP_URL = <?php echo json_encode(url('/')); ?>;
</script>
<script>
$(document).ready(function(){
    var openModal=<?php echo $openModal; ?>;
    if(openModal==1)
    {
            $('#stateModal').modal('show');
    }
});
</script>
<script type="text/javascript">
function saveState()
{
  
  var editedOrFreshEntries=<?php echo $openModal; ?>;
  var ftoInstructorName=$("#ftoInstructorName").val();
  var ftoInstructorId=$("#ftoInstructorId").val();
  var ftoId=$("#ftoId").val();
   if(editedOrFreshEntries!=1)
   {
       
       if(ftoId=='' || ftoId==null)
        {
          alert("Select FTO Name");
          return false;
        }
        
        if(ftoInstructorName=='' || ftoInstructorName==null)
        {
          alert("Enter Instructor Name");
          return false;
        }
        
        
    }
    
    else
       {
          if(editedOrFreshEntries!=0)
          {
              if(ftoId=='' || ftoId==null)
                {
                  alert("Select FTO Name");
                  return false;
                }
        
        
               if(ftoInstructorName=='' || ftoInstructorName==null)
               {
                 alert("Enter Instructor Name");
                 return false;
               }
           } 
           
           
        
       }
       
       
    
    swal({
          title: "Are you sure?",
          text: "Save Instructor !",
          icon: "warning",
          buttons: [
            'No !',
            'Yes !'
          ],
          dangerMode: true,
        }).then(function(isConfirm) {
          if (isConfirm) {
            swal({
              title: 'Instructor Saved!',
              text: 'Instructor Saved successfully!',
              icon: 'success'
            }).then(function() {
              
                        var url =APP_URL+'/ftoinstrctorlist';
                        $.ajax({
                          headers: { 'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content') },
                          type: "POST",
                          url: url,
                           data:{
                                'editedOrFreshEntries':editedOrFreshEntries,
                                'ftoInstructorName': ftoInstructorName,
                                'ftoInstructorId': ftoInstructorId,
                                'ftoId': ftoId,
                                },
                          success: function(newdata)
                          {
                            window.location = url;
                          }

                        });
            });
          } else {
            swal("Cancelled", "Your are cancelled :)", "error");
          }
        });

}


function deleteState(ftoInstructorId)
{

    swal({
          title: "Are you sure?",
          text: "Delete Instructor !",
          icon: "warning",
          buttons: [
            'No !',
            'Yes !'
          ],
          dangerMode: true,
        }).then(function(isConfirm) {
          if (isConfirm) {
            swal({
              title: 'Delete Instructor!',
              text: 'Instructor Deleted successfully!',
              icon: 'success'
            }).then(function() {
              
                        var url =APP_URL+'/ftoinstrctorlist';
                        $('#loader').show();
                        $.ajax({
                          headers: { 'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content') },
                          type: "GET",
                          url: url,
                           data:{
                                'deleteOrEditState':'deleteSmstemplate',
                                'ftoInstructorId': ftoInstructorId,
                                 },
                          success: function(newdata)
                          {
                            window.location = url;
                           
                         }

                        });
            });
          } else {
            swal("Cancelled", "Your are cancelled :)", "error");
          }
        });
}
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sumagoinfotech/public_html/rpa/resources/views/website/fto/instructor.blade.php ENDPATH**/ ?>