<?php $__env->startSection('title'); ?>
    Video Gallery
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('website.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('website.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="row text-center justify-content-center" style="margin-top: 20;">
      <div class="col-md-12">
          <h1 class=" text-uppercase text-primary">VIDEO GALLERY</h1>

      </div>
  </div>
    <div class="container my-5">
      <div class="card box-shadow-1 mb-2">
        <div class="card-body">
        <div class="row">
            <?php if($allVideoGalleryList): ?>
            <?php $__currentLoopData = $allVideoGalleryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getallVideoGalleryList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-2">
              <div class="card box-shadow-1 mb-2">
              <div class="card-body">
               <div class="row no-gutters">
                 <div class="col-md-6 courses-card-image">
                    <center>
                      <iframe src="<?php echo e(url($getallVideoGalleryList->url)); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" style="height: 150px; width: 160px;" allowfullscreen></iframe>
                    </center>
                 </div>
                 <div class="col-md-2"></div>
                 <div class="col-md-4">
                  
                    <h5 class="card-title">Name</h5>
                    <p class="card-text">Experience</p>
                    <p class="card-text">Area</p>
                     
                  
                </div>
            </div>
        </div>
    </div></div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
          <div class="alert alert-danger" role="alert" style="align:center">
          No Video Uploaded Yet !!
          </div>
          <?php endif; ?>
      </div>
      <br>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rpapilot/public_html/rpa/resources/views/website/videogallery/videogallery.blade.php ENDPATH**/ ?>