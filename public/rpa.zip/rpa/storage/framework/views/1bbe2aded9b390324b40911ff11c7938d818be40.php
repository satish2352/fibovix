 <?php $__env->startSection('title'); ?> Pilot Details <?php $__env->stopSection(); ?> <?php $__env->startSection('header'); ?> <?php echo $__env->make('website.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?> <?php echo $__env->make('website.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php $CommonService = app('App\Http\Controllers\Common\CommonController'); ?>

<div class="container  my-5">
    <div class="row justify-content-center">
        <div class="div col-md-8 order-md-2 order-2">
                <?php if(count($ftoDetails) > 0): ?> <?php $__currentLoopData = $ftoDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getallFTOs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card  box-shadow-1">
                    <div class="card-body">
                        <h5 class="card-title">Description</h5>
                        <p class="card-text" style=" text-align: justify;"><?php echo e($getallFTOs->description); ?></p>
                    </div>
                </div>

                <?php $courses=DB::select("SELECT * FROM `courses` WHERE `courseownerid`='".$getallFTOs->id."' and `createdBy`='0' "); ?>
                    <?php if($courses): ?> <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card  box-shadow-1 my-3">
                        <div class="card-body">
                            <h5 class="card-title">More Courses</h5>
                            <div class="row">
                                <div class="col-md-4 active mb-3">
                                    <div class="card">
                                        <?php if($getallCourses->image): ?>
                                        <img class="card-img-top" src="<?php echo env('APP_URL'); ?>public/asset/Course/Image/<?php echo e($courses->image); ?>" alt="Card image"> <?php else: ?>
                                        <img class="card-img-top" src="<?php echo env('APP_URL'); ?>public/asset/noImage.png" alt="Card image"> <?php endif; ?>
                                        <div class="card-body">
                                            <p class="card-text"></p>
                                            <a href="<?php echo e(route('webcoursedetails',array('id'=>$courses->id))); ?>" class="btn btn-outline-secondary">Details</a>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    <?php else: ?>
                    <!--<div class="alert alert-warning my-5" role="alert">-->
                    <!--    <h4 class="alert-heading">No Data Found</h4>-->
                    <!--    <p>Course No Added Yet By FTO</p>-->
                    <!--</div>-->
                    <?php endif; ?>
                    
                    <br>
                    <div class="card  box-shadow-1">
                    <div class="card-body">
                        <h5 class="card-title">FTO Instructor</h5>
                        <p class="card-text"> <?php 
                                    $ftoInsRes=DB::select("SELECT * FROM `ftoinstructor` WHERE `underFTO`='".$getallFTOs->id."' "); 
                                ?>
                                    <?php if($ftoInsRes): ?> 
                                    <?php $__currentLoopData = $ftoInsRes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$ftoIns): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($ftoIns->instructorName); ?> </br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                    <?php else: ?>
                                    <?php echo e('-'); ?>

                                    <?php endif; ?>
                        </p>
                        </div>
                    </div>
                    
                    <br>
                    
                     <div class="card  box-shadow-1">
                        <div class="card-body">
                            <h5 class="card-title">Photo Gallary</h5>
                            <div class="card-text d-flex justify-content-between">
                                <?php $allPhotoGalleryList=DB::select("SELECT * FROM `photogallery` where whosePhotoGallery='".$getallFTOs->id."' and PhotoGalleryBy='1'"); ?>
                                <?php if(count($allPhotoGalleryList)>0): ?>
                                 <?php $__currentLoopData = $allPhotoGalleryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getallPhotoGalleryList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <div class="col-md-4">
                                  <a href="#" data-target="#modalIMG<?php echo e($getallPhotoGalleryList->id); ?>" data-toggle="modal" class="color-gray-darker c6 td-hover-none">
                                    <div class="ba-0 ds-1">
                                      <img alt="Card image cap" class="card-img-top" src="<?php echo env('APP_URL');?>public/asset/PhotoGallery/Image/<?php echo e($getallPhotoGalleryList->image); ?>" style="height: 250px; width: 300%;" />
                                      <div class="card-body">
                                        <?php echo e($getallPhotoGalleryList->title); ?>

                                      </div>
                                    </div>  
                                  </a>
                               </div>
                
                                <div aria-hidden="true" aria-labelledby="myModal" class="modal fade" id="modalIMG<?php echo e($getallPhotoGalleryList->id); ?>" role="dialog" tabindex="-1">
                                  <div class="modal-dialog modal-lg" role="document">
                                    <div class="modal-content">
                                      <div class="modal-body mb-0 p-0">
                                        <img src="<?php echo env('APP_URL');?>public/asset/PhotoGallery/Image/<?php echo e($getallPhotoGalleryList->image); ?>" alt="" style="height: 500px; width: 500%;">
                                      </div>
                                      <div class="modal-footer">
                                        <button class="btn btn-outline-primary btn-lg btn-rounded btn-md ml-4 text-center" data-dismiss="modal"  type="button">Close</button>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <div class="alert alert-danger" role="alert" style="align:center">
                                  No Photo Uploaded Yet !!
                                </div>
                                <?php endif; ?>
                                                                                                                                                                                                                                                                                                                                                                                    
                            </div>
                        </div>
                    </div>
                    
                    <br>
                     <div class="card  box-shadow-1">
                        <div class="card-body">
                            <h5 class="card-title">Videos Gallary</h5>
                            <div class="card-text d-flex justify-content-between">
                                
                                <?php $allVideoGalleryList=DB::select("SELECT * FROM `videogallery` where whoseVideoGallery='".$getallFTOs->id."' and VideoGalleryBy='1'"); ?>
                                <?php if($allVideoGalleryList): ?>
                                <?php $__currentLoopData = $allVideoGalleryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getallVideoGalleryList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4 mb-2">
                                  <div class="card box-shadow-1 mb-2">
                                  <div class="card-body">
                                   <div class="row no-gutters">
                                     <div class="col-md-6 courses-card-image">
                                        <center>
                                          <iframe src="<?php echo e(url($getallVideoGalleryList->url)); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" style="height: 150px; width: 160px;" allowfullscreen></iframe>
                                        </center>
                                     </div>
                                     <div class="col-md-2"></div>
                                     <div class="col-md-4">
                                      
                                        <!--<h5 class="card-title">Name</h5>-->
                                        <!--<p class="card-text">Experience</p>-->
                                        <!--<p class="card-text">Area</p>-->
                                     </div>
                                     </div>
                                        </div>
                                    </div>
                                </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php else: ?>
                              <div class="alert alert-danger" role="alert" >
                              <span style="align:center">No Video Uploaded Yet !! </span>
                              </div>
                              <?php endif; ?>
                            </div>
                            </div>
                        </div>
                    
                    
        </div>

        <div class="div col-md-4 mb-2">
            <div class="card box-shadow-1">
                <img src="<?php echo env('APP_URL'); ?>public/asset/FTOLogo/Image/<?php echo e($getallFTOs->FTOLogo); ?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-text"><?php echo e($getallFTOs->FTOName); ?></h5>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><span class="">State : </span><span class="font-weight-bold"> <?php $state=$CommonService->getPerticularStateById($getallFTOs->stateID); ?><?php echo e($state[0]->name); ?></span></li>
                    <li class="list-group-item"><span class="">Mobile : </span><span class="font-weight-bold"><?php echo e($getallFTOs->mobile); ?></span></li>
                    <li class="list-group-item"><span class="">City : </span><span class="font-weight-bold"><?php $city=$CommonService->getPerticularCityById($getallFTOs->cityId); ?> <?php echo e($city[0]->name); ?></span></li>
                    <li class="list-group-item"><span class="">zipcode : <span class="font-weight-bold"><?php echo e($getallFTOs->pinCode); ?>  </span>
                    
                    <li class="list-group-item"><span class="">Address : </span><span class="font-weight-bold"><?php if($getallFTOs->address1): ?><?php echo e($getallFTOs->address1); ?>,<?php endif; ?> 
                                                                             <?php if($getallFTOs->address2): ?><?php echo e($getallFTOs->address2); ?>, <?php endif; ?> 
                                                                             <?php if($getallFTOs->address3): ?><?php echo e($getallFTOs->address3); ?> <?php endif; ?></span></li>
                </ul>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php else: ?>
        <div class="alert alert-warning my-5" role="alert">
            <h4 class="alert-heading">No Data Found</h4>
            <p>The following FTO doesn't exits in Rpapilot database, Kindly Refresh the Page. You may also contact rpapilot customer care for further enquiry</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?> <?php $__env->startSection('footer'); ?> 
<?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/infosolution/public_html/rpa/resources/views/website/fto/ftodetails.blade.php ENDPATH**/ ?>