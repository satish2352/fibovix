
						<?php
						
						//dd($admincityList);
						?>
						<div class="form-group row">
							<label class="col-sm-12 col-md-1 col-form-label"><span style="color: red">*</span></label>
							<div class="col-sm-12 col-md-11">
							    <select class="form-control" name="city" required="" id="city" >
							        <option value="">Select City</option>
                                            <?php $__currentLoopData = $admincityList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$admincityList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($admincityList['id']); ?>" ><?php echo e($admincityList['city']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							    </select>
							</div>
						</div><?php /**PATH /home/infosolution/public_html/rpa/resources/views/common/adminCity.blade.php ENDPATH**/ ?>