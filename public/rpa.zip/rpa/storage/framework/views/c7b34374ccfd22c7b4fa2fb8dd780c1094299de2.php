

<?php $__env->startSection('title'); ?>
    STUDENT REGISTRATION
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('website.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('website.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


 <div class="row text-center justify-content-center" style="margin-top: 15px;">
            <div class="col-md-10">
                <h1 class=" text-uppercase text-primary">STUDENT REGISTRATION</h1>

            </div>
            <?php if(session('success')): ?>
             <span class="alert alert-success" role="alert">
                 <strong><?php echo e(session('success')); ?></strong>
             </span>
            <?php endif; ?>
        </div>
<div class="row position-relative">
        <div class="container my-5" style="max-width: 800px">
            <div class="col-md-12">
                <div class="card shadow" style="margin-bottom: 150px;">
                    <div class="card-body">
                        <form action="<?php echo e(route('savestudentregforms')); ?>" method="Post" class="mb-5" enctype="multipart/form-data">
                                                       
                            <?php echo csrf_field(); ?>
                                <div class="form-row justify-content-between">
                                <div class="form-group col-md-4">
                                    <label for="">First Name <span class="text-primary">*</span></label>
                                    <input name="firstName" type="text" class="form-control" id=""
                                           placeholder="Provide First Name" value=""  oninput="this.value = this.value.replace(/[^a-zA-Z\s.]/g, '').replace(/(\..*)\./g, '$1');" required>
                                </div>
                                
                                <div class="form-group col-md-4">
                                    <label for="">Middle Name <span class="text-primary">*</span></label>
                                    <input name="middleName" type="text" class="form-control" id=""
                                           placeholder="Provide Middle Name" oninput="this.value = this.value.replace(/[^a-zA-Z\s.]/g, '').replace(/(\..*)\./g, '$1');" value="" required>
                                </div>

                                <div class="form-group col-md-4">
                                    <label for="">Last Name <span class="text-primary">*</span></label>
                                    <input name="lastName" type="text" class="form-control" id=""
                                           placeholder="Provide Last Name" oninput="this.value = this.value.replace(/[^a-zA-Z\s.]/g, '').replace(/(\..*)\./g, '$1');" value="" required>
                                </div>
                            </div>
                           
                            
                            <input name="courseId" value="<?php echo $courseId; ?>" >
                            
                            <div class="form-row justify-content-between">
                                <div class="form-group col-md-6">
                                    <label for="">Email Address <span class="text-primary">*</span></label>
                                    <input name="email" type="email" class="form-control" id=""
                                           placeholder="Provide Email Address" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="">Password <span class="text-primary">*</span></label>
                                    <input name="password" type="password" class="form-control" id="password" placeholder="Provide Password" required>
                                </div>
                            </div>
                            <div class="form-row justify-content-between">
                                 <div class="form-group col-md-6">
                                    <label for="">Password Confirmation<span class="text-primary">*</span></label>
                                    <input name="password_confirmation" type="password" class="form-control" id="confpassword"
                                           placeholder="Provide Password Confirmation" required>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="">Mobile Number <span class="text-primary">*</span></label>
                                    <input name="mobile" type="text" class="form-control" id="" placeholder="Provide Mobile Number" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  pattern="^\d{10}$" required>
                                </div>
                               
                            </div>
                            
                            <div class="form-row justify-content-between">
                                <div class="form-group col-md-6">
                                    <label for="createInputState">State <span class="text-primary">*</span></label>
                                   <select name="stateId" id="stateId" class="selectpicker form-control " title="Choose..." data-live-search="true" onchange="getCity();" required>
                                        <option value="">Choose State</option>
                                        <?php $__currentLoopData = $stateList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($state->id); ?>" ><?php echo e($state->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
                                    </select>
                                </div>
                                <div class="form-group col-md-6" >
                                
                                    
                                </div>
                            </div>
                            <div id="city"></div>
                            <div class="form-row justify-content-between">
                                 <div class="form-group col-md-6">
                                    <label for="createInputProfession">Profession <span
                                            class="text-primary">*</span></label>
                                            
                                    <select name="profession" class="selectpicker form-control " title="Choose..." data-live-search="true" required>
                                        <option value="">Select Profession</option>
                                        <option value="Diploma">Diploma</option>
                                        <option value="BE" >BE</option>
                                        <option value="ME" >ME</option>
                                        
                                    </select>
                                </div> 
                                
                                
                                <div class="form-group col-md-6">
                                    <label for="">Aadhar ID </label>
                                    <input name="aadharNumber" type="text" class="form-control" id=""
                                           placeholder="Provide aadhar ID" pattern="^\d{12}$" >
                                </div>
                                
                            </div>

                             <div class="form-row justify-content-between">
                                <div class="form-group col-md-6">
                                   <label for="">10th Certificate <span class="text-primary">*</label><br>
                                   <input type="file" id="image" name="certificate"  accept=" .png, .jpg, .jpeg " required />
                                </div>
                                
                                
                                <div class="form-group col-md-6">
                                   <label for="">Passport Photo <span class="text-primary">*</label><br>
                                   <input type="file" id="image1" name="passportPhoto"  accept=" .png, .jpg, .jpeg " required />
                                </div>
                                
                            </div>
                            <div class="form-row justify-content-between">
                                <div class="form-group col-md-6">
                                    <label for="createInputState">Address Proof<span class="text-primary">*</span></label>
                                   <select name="addressProof" id="select" class="selectpicker form-control " title="Choose..." required>
                                        <option value="">Choose Address Proof</option>
                                        <option value="Passport">Passport</option>
                                        <option value="Aadhar">Aadhar</option>
                                        <option value="Driving License">Driving License</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-row justify-content-between">
                                <div class="form-group col-md-6">
                                   <label for="">Address Proof Front <span class="text-primary">*</label><br>
                                   <input type="file" id="image2" name="addressProofFront"  accept=" .png, .jpg, .jpeg " required />
                                </div>
                                
                                
                                <div class="form-group col-md-6">
                                   <label for="">Address Proof Back <span class="text-primary">*</label><br>
                                   <input type="file" id="image3" name="addressProofBack"  accept=" .png, .jpg, .jpeg " required />
                                </div>
                                
                            </div>
                            <div class="form-row justify-content-between">
                            <div class="form-group col-md-6">
                                    <label for="">Address Proof ID Number <span class="text-primary">*</label>
                                    <input name="idNumber" type="text" class="form-control" id=""
                                           placeholder="Provide ID" required="">
                            </div>
                            </div>
                            <div class="form-row justify-content-between">
                                <div class="form-group col-md-12">
                                <input type="checkbox" name="checkbox1" value="check" required="">&nbsp;I agree to accept all FTO's Terms and Conditions. 
                            </div>
                            </div>
                            <div class="form-row justify-content-between">
                                <div class="form-group col-md-12">
                                <input type="checkbox" name="checkbox" value="check" id="agree" data-toggle="modal" data-target="#myModal" required="">&nbsp;I give my acceptance to Indemnity Bond. 
                            </div>
                            </div>


                             <div class="form-row justify-content-between">
                            <div class="form-group col-md-6">
                                <button type="submit" class="btn btn-primary w-100" onclick="return Validate()">Submit</button>
                            </div>
                            <div class="form-group col-md-6">
                                <button type="reset" class="btn btn-primary w-100">Reset</button>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>

    </div>


    <!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Modal title</h4>
      </div>
      <div class="modal-body">
        <div class="form-group col-md-6" >
                                <label for="createInputState">FTO Name <span class="text-primary">*</span></label>
                                    
                                        <?php $__currentLoopData = $allContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$allContent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p value="<?php echo e($allContent->id); ?>">
                                           <?php echo e($allContent->bondContent); ?> 
                                        </p>
                                        
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    
                                </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
</div>

<script type="text/javascript">
        function Validate() {
            var password = document.getElementById("password").value;
            var confpassword = document.getElementById("confpassword").value;
            if (password != confpassword) 
            {
                alert("Password Not Matched, Please Confirm Password");
                return false;
            }
            alert("Password Confirmed");
            return true;
        }
</script>



   <script type="text/javascript">
            $(document).ready(function(){
                //Image file input change event
                $("#image").change(function(){
                    readImageData(this);//Call image read and render function
                });
            });
             
            function readImageData(imgData){
                if (imgData.files && imgData.files[0]) {
                    var readerObj = new FileReader();
                    
                    readerObj.onload = function (element) {
                        $('#preview_img').attr('src', element.target.result);
                    }
                    
                    readerObj.readAsDataURL(imgData.files[0]);
                }
            }
        </script>   
        <script type="text/javascript">
            $(document).ready(function(){
                //Image file input change event
                $("#image1").change(function(){
                    readImageData1(this);//Call image read and render function
                });
            });
             
            function readImageData1(imgData){
                if (imgData.files && imgData.files[0]) {
                    var readerObj = new FileReader();
                    
                    readerObj.onload = function (element) {
                        $('#preview_img1').attr('src', element.target.result);
                    }
                    
                    readerObj.readAsDataURL(imgData.files[0]);
                }
            }
        </script>
        <script type="text/javascript">
            $(document).ready(function(){
                //Image file input change event
                $("#image2").change(function(){
                    readImageData2(this);//Call image read and render function
                });
            });
             
            function readImageData2(imgData){
                if (imgData.files && imgData.files[0]) {
                    var readerObj = new FileReader();
                    
                    readerObj.onload = function (element) {
                        $('#preview_img2').attr('src', element.target.result);
                    }
                    
                    readerObj.readAsDataURL(imgData.files[0]);
                }
            }
        </script>
         <script type="text/javascript">
            $(document).ready(function(){
                //Image file input change event
                $("#image3").change(function(){
                    readImageData3(this);//Call image read and render function
                });
            });
             
            function readImageData3(imgData){
                if (imgData.files && imgData.files[0]) {
                    var readerObj = new FileReader();
                    
                    readerObj.onload = function (element) {
                        $('#preview_img3').attr('src', element.target.result);
                    }
                    
                    readerObj.readAsDataURL(imgData.files[0]);
                }
            }
        </script>
        <script type="text/javascript">
            $('input[type="checkbox"]').on('change', function(e){
   if(e.target.checked){
     $('#myModal').modal();
   }
});
        </script>
        <script type="text/javascript">
    var APP_URL = <?php echo json_encode(url('/')); ?>

</script>

<script>
    
    function getCity(){
            var url=APP_URL+'/getcity';
            let stateId = $('#stateId').val();
            //alert(stateId); 
            if(stateId==null || stateId=='')
            {
                alert("Select City");
                return false;
            }
            
            $.ajax({
                url:url,
                type: 'post',
                dataType: 'html',
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    'stateId': stateId
                },
                
                
                success: function (response) {
                    $('#city').empty();
                    $('#city').append(response);
                    $('#city').show();
                }
            });
    }
    
    
</script>



<!-- <script type="text/javascript">
    function ShowHideDiv() 
    {
        var category = document.getElementById("category").value;
        var categoryId=category.toString().split("*");
        var requiredDiv = document.getElementById("requiredDiv");
        requiredDiv.style.display = categoryId[1] == "1" ? "block" : "none";
    }
</script>  -->


   <?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sumagoinfotech/public_html/rpa/resources/views/website/studentregistration/studentregistration.blade.php ENDPATH**/ ?>