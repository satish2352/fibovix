<?php $__env->startSection('title'); ?>
    Pilot Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('website.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('website.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .cardNew{
  height: 178px;
} 
.scrollable{
  overflow-y: auto;
  max-height: 150px;
}

.cardNew-body {
    flex: 1 1 auto;
    padding: 1.25rem;
}


.boxNew-shadow-1 {
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.07), 0 1px 2px rgba(0, 0, 0, 0.09);
    transition: all 0.3s cubic-bezier(.25, .8, .25, 1);
}


.cardNewPhoto{
  height: 256px;
}

.scrollableNew {
    overflow-y: auto;
    max-height: 256px;
}

.cardNewPhoto-body {
    flex: 1 1 auto;
    padding: 1.25rem;
}


modal-contentNew {
    position: relative;
    display: flex;
    flex-direction: column;
    width: 100%;
    pointer-events: auto;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid rgba(0, 0, 0, 0.2);
    border-radius: 0.3rem;
    outline: 0;
}
</style>
<div class="container my-5">
    <?php //dd($result); ?>
     <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$pilot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row justify-content-between">
                <div class="div col-md-8 order-md-1 order-2">
                    
                    <div class="card  box-shadow-1 my-2">
                        <div class="card-body">
                            <h5 class="card-title">Description</h5>
                            <?php if($pilot->experience!=''): ?>
                            <p class="card-text"><?php echo e($pilot->experience); ?></p>
                            <?php else: ?>
                            <div class="alert alert-danger" role="alert" >
                            <span style="align:center">No Description Uploaded Yet !! </span>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <?php if(count($pilotrdroneinfo)): ?>
                    <div class="cardNew  box-shadow-1  my-2">
                    <div class="cardNew-body scrollable ">
                            <h5 class="card-title">Drone Information</h5>
                            <div class="card-text d-flex justify-content-between">
                            <table class="table table-striped" id="pageDataTable" role="grid" aria-describedby="DataTables_Table_0_info" style="border: 1px solid;">
                     	    <thead>
								<tr>
								    <th>Sr.No.</th>
								    <th>Drone Make</th>
								    <th>Manufacturer Name</th>
								    <th>UIN</th>
								    <th>DAN</th>
								    <!--<th>Drone Serial Number</th>-->
								</tr>
							</thead>
							<tbody>
							    <!--sr no drone_make drone_manu uin dan-->
							    
							    <?php if(count($pilotrdroneinfo)): ?>
							    <?php $__currentLoopData = $pilotrdroneinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$pilotDrone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($pilotDrone->droneMake); ?></td>
                                    <td><?php echo e($pilotDrone->drnManufacturarName); ?></td>
                                    <td><?php echo e($pilotDrone->uinnumber); ?></td>
                                    <td><?php echo e($pilotDrone->danNumber); ?></td>
                                    
                                    <!--<td><?php echo e($pilotDrone->droneSerialNumber); ?></td>-->
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
							</tbody>
						    </table>
                            </div>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="card  box-shadow-1 my-2">
                        <div class="card-body">
                            <h5 class="card-title">Drone Information</h5>
                            <div class="alert alert-danger" role="alert" >
                                
                                  <span style="align:center">No Drone Information Uploaded Yet !! </span>
                                  </div>
                        </div>
                    </div>
                    <?php endif; ?>
                
                    <?php $allPhotoGalleryList=DB::select("SELECT * FROM `photogallery` where whosePhotoGallery='".$pilot->id."' and PhotoGalleryBy='0'"); ?>
                    <?php if(sizeof($allPhotoGalleryList)>0): ?>
                   <div class="cardNewPhoto  box-shadow-1  my-2">
                      <div class="cardNewPhoto-body scrollableNew ">
                            <h5 class="card-title">Photo Gallery</h5>
                            <br>
                            <div class="card-text d-flex justify-content-between">
                                
                                <?php if(count($allPhotoGalleryList)>0): ?>
                                 <?php $__currentLoopData = $allPhotoGalleryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getallPhotoGalleryList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <div class="col-md-3">
                                  <a href="#" data-target="#modalIMG<?php echo e($getallPhotoGalleryList->id); ?>" data-toggle="modal" class="color-gray-darker c6 td-hover-none">
                                    <div class="ba-0 ds-1">
                                      <img alt="Card image cap" class="card-img-top" src="<?php echo env('APP_URL');?>public/asset/PhotoGallery/Image/<?php echo e($getallPhotoGalleryList->image); ?>" style="height: 150px; width: 150px;" />
                                      <div class="card-body">
                                        <?php echo e($getallPhotoGalleryList->title); ?>

                                      </div>
                                    </div>  
                                  </a>
                               </div>
                
                                <div aria-hidden="true" aria-labelledby="myModal" class="modal fade" id="modalIMG<?php echo e($getallPhotoGalleryList->id); ?>" role="dialog" tabindex="-1">
                                  <div class="modal-dialog modal-lg" role="document">
                                    <div class="modal-content" style="width: 55%; height:450px">
                                      <div class="modal-body" style="height: 379px;">
                                        <img src="<?php echo env('APP_URL');?>public/asset/PhotoGallery/Image/<?php echo e($getallPhotoGalleryList->image); ?>" alt="" style="height: 400px; width: 400px;">
                                      </div>
                                      <!--<div class="modal-footer">-->
                                      <!--  <button class="btn btn-outline-primary btn-lg btn-rounded btn-md text-center" data-dismiss="modal"  type="button">Close</button>-->
                                      <!--</div>-->
                                    </div>
                                  </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <div class="alert alert-danger" role="alert" >
                                  <span style="align:center">No Photo Uploaded Yet !! </span>
                                  </div>
                                <?php endif; ?>
                                                                                                                                                                                                                                                                                                                                                                                    
                            </div>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="card  box-shadow-1 my-2">
                        <div class="card-body">
                            <h5 class="card-title">Photo Gallery</h5>
                            <div class="alert alert-danger" role="alert" >
                                
                                  <span style="align:center">No Photo Uploaded Yet !! </span>
                                  </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php $allVideoGalleryList=DB::select("SELECT * FROM `videogallery` where whoseVideoGallery='".$pilot->id."' and VideoGalleryBy='0'"); ?>
                    <?php if(count($allVideoGalleryList)>0): ?>
                     <div class="cardNewPhoto  box-shadow-1  my-2">
                      <div class="cardNewPhoto-body scrollableNew ">
                            <h5 class="card-title">Videos Gallery</h5>
                            <div class="card-text d-flex justify-content-between">
                                
                                
                                <?php if($allVideoGalleryList): ?>
                                <?php $__currentLoopData = $allVideoGalleryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getallVideoGalleryList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4 mb-2">
                                  <div class="card box-shadow-1 mb-2">
                                  <div class="card-body">
                                   <div class="row no-gutters">
                                     <div class="col-md-6 courses-card-image">
                                        <center>
                                          <iframe src="<?php echo e(url($getallVideoGalleryList->url)); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" style="height: 150px; width: 160px;" allowfullscreen></iframe>
                                        </center>
                                     </div>
                                     <div class="col-md-2"></div>
                                     <div class="col-md-4">
                                      
                                        <!--<h5 class="card-title">Name</h5>-->
                                        <!--<p class="card-text">Experience</p>-->
                                        <!--<p class="card-text">Area</p>-->
                                     </div>
                                     </div>
                                        </div>
                                    </div>
                                </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php else: ?>
                              <div class="alert alert-danger" role="alert" >
                              <span style="align:center">No Video Uploaded Yet !! </span>
                              </div>
                              <?php endif; ?>
                            </div>
                        </div>
                    </div>
                     <?php else: ?>
                    <div class="card  box-shadow-1 my-2">
                        <div class="card-body">
                             <h5 class="card-title">Videos Gallery</h5>
                            <div class="alert alert-danger" role="alert" >
                                
                                 <span style="align:center">No Video Uploaded Yet !! </span>
                                  </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                </div>
                                    
                                    
                    
                                    
                                    
                <div class="col-md-4  order-md-1">
                    <div class="card position-relative">
                        <div class="fto-pilots-card-active-badge">
                                <span class="box-shadow-1 font-weight-normal align-middle  badge badge-success badge-pill text-white mx-1" style="font-size: 12px"><i class="material-icons-outlined" style="font-size: 18px">check</i> RPA Pilot Verified</span>
                                <?php if($pilot->ftoId): ?>
                                <?php if($pilot->ftoApproved==1): ?>
                                <span class="box-shadow-1 font-weight-normal align-middle  badge badge-info badge-pill text-white mx-1" style="font-size: 12px"><i class="material-icons-outlined" style="font-size: 18px">check</i> FTO  Verified</span>
                                <?php endif; ?>
                                <?php else: ?>
                                <!--<span class="box-shadow-1 font-weight-normal align-middle  badge badge-danger badge-pill text-white mx-1" style="font-size: 12px">FTO Details Not Available</span>-->
                                <?php endif; ?>
                        </div>
                        
                        <div class="card-header text-center">
                            <img class="img-fluid" src="<?php echo e(env('APP_URL')); ?>/public/asset/website/images/pilots/rpapilot_default_300_300.png">
                        </div>
                       
                        <div class="card-body">
                            <h3 class="card-title align-items-center"><?php echo e($pilot->firstName); ?> <?php echo e($pilot->middleName); ?> <?php echo e($pilot->lastName); ?>  </h3>
                            <h6 class="card-subtitle mb-2 text-muted"><?php //$proffession=$pilot->proffession; $resultNew=DB::select("select FTOName from ftoregistration where id='".$proffession."'"); ?> </h6>
                        </div>
                        <ul class="list-group list-group-flush"><?php //dd("hello"); ?>
                            <li class="list-group-item"><span class="font-weight-bold">FTO : </span><?php $ftoId=$pilot->ftoId; if($ftoId!=null) { $resultNew=DB::select("select FTOName from ftoregistration where id='".$ftoId."'"); echo $resultNew[0]->FTOName; } else { echo "FTO Details Not Available"; } ?> </li>
                            <!--<li class="list-group-item"><span class="font-weight-bold">Email Address : </span><?php echo e($pilot->email); ?></li>-->
                            <!--<li class="list-group-item"><span class="font-weight-bold">Mobile No : </span><?php echo e($pilot->mobile); ?></li>-->
                            <li class="list-group-item"><span class="font-weight-bold">OAN : </span><?php if($pilot->oannumber): ?> <?php echo e($pilot->oannumber); ?> <?php else: ?> <?php echo e('-'); ?> <?php endif; ?></li>
                            <li class="list-group-item"><span class="font-weight-bold">UAOP NO : </span>
                             <?php if(count($pilotrdroneinfo)): ?>
							    <?php $__currentLoopData = $pilotrdroneinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$pilotDrone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($pilotDrone->uaopnumber); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?> <?php echo e('NA'); ?> <?php endif; ?></li>
                            <li class="list-group-item"><span class="font-weight-bold">State : </span><?php $stateID=$pilot->stateID; $resultNew=DB::select("SELECT * FROM `states` where id='".$stateID."'"); ?> <?php echo e($resultNew[0]->name); ?></li>
                            <li class="list-group-item"><span class="font-weight-bold">City : </span><?php $cityId=$pilot->cityId; $resultNew=DB::select("SELECT * FROM `cities` where id='".$cityId."'"); ?> <?php echo e($resultNew[0]->name); ?></li>
                            <li class="list-group-item"><span class="font-weight-bold">Want To Hire Pilot : </span><a class="btn btn-primary" href="http://rpapilot.com/hirepilot"role="button" >Click Here</a></li>

                        </ul>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            
        </div>
        
 <script>
    $(document).ready(function()
    {
        $('#pageDataTable').DataTable({searching: false,ordering: false,lengthChange: false,showNEntries: false});
    });
</script>       
  <?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rpapilot/public_html/rpa/resources/views/website/pilot/pilotdetails.blade.php ENDPATH**/ ?>