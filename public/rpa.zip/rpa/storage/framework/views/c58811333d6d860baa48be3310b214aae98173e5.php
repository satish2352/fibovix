<?php $CommonService = app('App\Http\Controllers\Common\CommonController'); ?>
<div class="row">
   
   <div class="form-group col-sm-4" >
      <label>State</label>
      <select name="state" id="stateId" class="form-control" onchange="getResultByState(this.value);" title="Choose..." data-live-search="true" required>
         <option value="">Choose State</option>
         <?php $__currentLoopData = $stateList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <option value="<?php echo e($state->id); ?>" <?php if($state->id==$stateId): ?> <?php echo e('selected'); ?> <?php endif; ?> ><?php echo e($state->name); ?></option>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
      </select>
   </div>
   
   <div class="form-group col-sm-4">
		<label>City</label>
		    <select class="form-control" name="city" required="" id="city" onchange="getResultByCity(this.value);" class="custom-select col-12">
		        <option value="">Select City</option>
                        <?php $__currentLoopData = $cityList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cityListNew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <option value="<?php echo e($cityListNew->id); ?>" <?php if($cityListNew->id==$cityId): ?> <?php echo e('selected'); ?> <?php endif; ?>  ><?php echo e($cityListNew->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    </select>
   </div>
   
   <div class="form-group col-sm-4">
   </div>
</div>
</form>
<div class="row table-responsive ">
   <table class="table table-striped" id="pageDataTable" role="grid" aria-describedby="DataTables_Table_0_info">
							<thead>
								<tr>
								    <?php
								    $count=0;
								    ?>
									<!--<th class="table-plus datatable-nosort"></th>-->
									<th>Sn.</th>
									<th>Name</th>
									<th>Mobile</th>
									<th>Category</th>
									<th>Email</th>
									<th>State</th>
									<th>City</th>
									<th>Details</th>
								
								</tr>
							</thead>
							<tbody>
							    
							    <?php if(count($allPilots) > 0): ?>
							    <?php
							    //dd($allPilots);
                                          foreach($allPilots as $getallPilots )
                                          {
                                ?>
								<tr>
								    <td><?php echo e(++$count); ?></td>
									<td><?php echo e($getallPilots->firstName); ?> <?php echo e($getallPilots->middleName); ?> <?php echo e($getallPilots->lastName); ?></td>
									<td><?php echo e($getallPilots->mobile); ?></td>
									<td><?php echo e($getallPilots->category); ?></td>
									<td><?php echo e($getallPilots->email); ?></td>
									<td><?php $state=$CommonService->getPerticularStateById($getallPilots->stateID);?>   <?php echo e($state[0]->name); ?></td>
			                        <td><?php $city=$CommonService->getPerticularCityById($getallPilots->cityId);?>  <?php echo e($city[0]->name); ?></td>
								
									<td>
									    <a class="btn btn-primary" href="#" role="button" >
									        View
								        </a>
								    </td>
								
								</tr>
								<?php
                                          }
                                          ?>
								
                                  <?php endif; ?>



							</tbody>
						</table>
</div>

<script>
    $(document).ready(function(){
    $('#pageDataTable').DataTable({searching: true,ordering: false,lengthChange: false,showNEntries: false});
  });
</script><?php /**PATH /home/sumagoinfotech/public_html/rpa/resources/views/website/pilot/pilotsearchajax.blade.php ENDPATH**/ ?>