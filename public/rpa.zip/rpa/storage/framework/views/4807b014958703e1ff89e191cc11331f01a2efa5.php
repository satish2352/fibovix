
<?php $__env->startSection('content'); ?>
<div class="main-container">
   <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
   <div class="pd-ltr-20 customscroll customscroll-10-p height-100-p xs-pd-20-10">
      <div class="min-height-200px">
         <div class="page-header">
            <div class="row">
               <div class="col-md-6 col-sm-12">
                  <div class="title">
                     <h4>Drone Information</h4>
                  </div>
                  <nav aria-label="breadcrumb" role="navigation">
                     <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashadmin')); ?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Drone List</li>
                     </ol>
                  </nav>
               </div>
               <div class="col-md-6 col-sm-12 text-right">
                  <div class="dropdown">
                     <a href="#stateModal" class="btn btn-primary" role="button" data-toggle="modal" data-target="#stateModal">
                     Add Drone Information
                     </a>
                     <div class="dropdown-menu dropdown-menu-right">
                        <a class="dropdown-item" href="#">Export List</a>
                        <a class="dropdown-item" href="#">Policies</a>
                        <a class="dropdown-item" href="#">View Assets</a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- Export Datatable start -->
         <div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
            <div class="clearfix mb-20">
               <div class="pull-left">
                  <h5 class="text-blue">Drone List</h5>
               </div>
            </div>
            <div class="row table-responsive ">
                              
               <table class="table table-striped" id="pageDataTable" role="grid" aria-describedby="DataTables_Table_0_info">
                  <thead>
                     <tr>
                        <th>Sr.No.</th>
                        <th>Category</th>
                        <th>UAOP Number</th>
                        <th>UAOP Validity</th>
                        <th>UIN Number</th>
                        <th>UIN Validity</th>
                        <!--<th>UAOP Validity</th>-->
                        <th>NPNT</th>
                        <th>Drone Serial Number</th>
                        <th>DAN Number</th>
                        <th>Drone Model No.</th>
                        <th>Drone Manufacturar Name</th>
                        <th>Insurance</th>
                        <th>Insurance Validity</th>
                        <th>Action</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php $__currentLoopData = $allPilotDrone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php $result=DB::select("select category from category where id='".$value->category."'"); ?> <?php echo e($result[0]->category); ?></td>
                        <td><?php echo e($value->uaopnumber); ?></td>
                        <td><?php echo e($value->uaopvalidity); ?></td>
                        <td><?php echo e($value->uinnumber); ?></td>
                        <td><?php echo e($value->uinvalidity); ?></td>
                        <!--<td><?php echo e($value->uaopvalidity); ?></td>-->
                        <td><?php echo e($value->npnt); ?></td>
                        <td><?php echo e($value->droneSerialNumber); ?></td>
                        <td><?php echo e($value->danNumber); ?></td>
                        <td><?php echo e($value->drnModelNum); ?></td>
                        <td><?php echo e($value->drnManufacturarName); ?></td>
                        <td><?php if($value->insurance=='1'): ?><?php echo e('Yes'); ?><?php else: ?> <?php echo e('No'); ?><?php endif; ?></td>
                        <td><?php echo e($value->insVal); ?></td>
                       
                        <td>
                           <!--<a href="<?php echo e(route('pilotdroneinfo',['id'=>$value->id,'deleteOrEditDrone'=>'editdrone'])); ?>" class="btn btn-edit btn-lg">-->
                           <!--<i class="icon-copy fi-pencil btngreen" title="Edit"></i>-->
                           <!--</a>-->
                           <a onclick="deleteDrone(<?php echo e($value->id); ?>)" class="btn btn-delete btn-lg"><i class="icon-copy fi-trash btndelete" title="Delete"></i></a>
                        </td>
                     </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                  </tbody>
               </table>
            </div>
         </div>
         <!-- Export Datatable End -->
      </div>
   </div>
   <!-- Modal -->
   <div class="modal fade" id="stateModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header">
               <h4 class="modal-title" id="myModalLabel">
                  <center>Add City</center>
               </h4>
            </div>
            <div class="modal-body">
              
               <form id="myForm" name="myForm">
             
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="form-row justify-content-between">
            <div class="form-group col-md-12">
                <label for="createInputProfession" class="col-sm-12 col-md-6 col-form-label">Category <span class="text-primary">*</span></label>
                <select name="category" class="form-control col-sm-12 col-md-6" id="category" title="Choose..." data-live-search="true" required="" onchange="ShowHideDiv()" id="category">

                    <option value="">Select Category</option>
                    <?php $__currentLoopData = $CategoryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$CategoryList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($CategoryList->id); ?>*<?php echo e($CategoryList->addInfoReq); ?>"><?php echo e($CategoryList->category); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div style="display: none" id="requiredDiv">
            <div class="form-row justify-content-between">
                <div class="form-group col-md-12">
                    <label for="" class="col-sm-12 col-md-6 col-form-label">UAOP Number <span class="text-primary">*</span></label>
                    <input name="uaopnumber" type="text" class="form-control" id="uaopnumber" placeholder="Provide UAOP Number">
                </div>
                <div class="form-group col-md-12">
                    <label for="" class="col-sm-12 col-md-6 col-form-label">UAOP Validity <span class="text-primary">*</span></label>
                    <input name="uaopvalidity" type="date" class="form-control" id="uaopvalidity">
                </div>
            </div>

            <div class="form-row justify-content-between">
                <div class="form-group col-md-12">
                    <label for="" class="col-sm-12 col-md-6 col-form-label">UIN Number </label>
                    <input name="uin" type="text" class="form-control" id="uin" placeholder="Provide UIN Number" value="">
                </div>

                <div class="form-group col-md-12">
                    <label for="" class="col-sm-12 col-md-6 col-form-label">UIN Validity </label>
                    <input name="uinvalidity" type="date" class="form-control" id="uinvalidity" value="">
                </div>
            </div>

            <div class="form-row justify-content-between">
                <div class="form-group col-md-12">
                    <label for="" class="col-sm-12 col-md-6 col-form-label">NPNT <span class="text-primary">*</span></label>
                    <input name="npnt" type="text" class="form-control" id="npnt" placeholder="Provide NPNT">
                </div>

                
            </div>
        </div>

        <div class="form-row justify-content-between">
            <div class="form-group col-md-12">
                <label for="" class="col-sm-12 col-md-6 col-form-label">Drone Serial No <span class="text-primary">*</span></label>
                <input name="d_serial_no" type="text" class="form-control" id="d_serial_no" placeholder="Provide Drone Serial Number" value="" required>
            </div>
            <div class="form-group col-md-12">
                <label for="createInputProfession" class="col-sm-12 col-md-12 col-form-label">DAN (Drone Acknowledge Number) Number <span class="text-primary">*</span></label>
                <input name="dan_no" type="text" class="form-control" id="dan_no" placeholder="Provide DAN Number" value="" required>
            </div>
        </div>

        <div class="form-row justify-content-between">
            <div class="form-group col-md-12">
                <label for="" class="col-sm-12 col-md-6 col-form-label">Drone Model No <span class="text-primary">*</span></label>
                <input name="drnModelNumber" type="text" class="form-control" id="drnModelNumber" placeholder="Provide Drone Serial Number" value="" required>
            </div>
            <div class="form-group col-md-12">
                <label for="createInputProfession" class="col-sm-12 col-md-6 col-form-label">Drone Manufacturar Name <span class="text-primary">*</span></label>
                <input name="drnManufacturar" type="text" class="form-control" id="drnManufacturar" placeholder="Provide Drone Manufacturar Name" value="" required>
            </div>
        </div>

        <div class="form-row justify-content-between">
            <div class="form-group col-md-12">
                <label for="" class="col-sm-12 col-md-12 col-form-label">Is Insurance Available? <span class="text-primary">*</span></label>
                <select name="insurance" id="insurance" class="col-sm-12 col-md-6 col-form-label" title="Choose..." data-live-search="true" onchange="ShowHideInsDiv()" required>
                    <option value="">Select</option>
                    <option value="1">Yes</option>
                    <option value="0">No</option>
                </select>
            </div>
            <!--<div style="display: none" id="requiredInsDiv">-->
            <div class="col-sm-12 col-md-6 col-form-label" style="display: none" id="requiredInsDiv">
                <label for="createInputProfession" class="col-sm-12 col-md-12 col-form-label"> Insurance Validity<span class="text-primary"> *</span></label>
                <input name="insVal" type="date" class="form-control" id="insVal">
            </div>
           
        </div>
        <div class="form-group ">
            <label for="createInputDescription" class="col-sm-12 col-md-12 col-form-label">Experience in Brief</label>
            <textarea name="profession_desc" class="form-control col-sm-12 col-md-12" id="profession_desc" placeholder="Provide Brief Description" rows="8"></textarea>
        </div>

       
    </div>
    <button type="button" class="btn btn-success" onclick="saveDrone();">Save</button>
     <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>

</form>
            </div>
         </div>
      </div>
   </div>
</div>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script type="text/javascript">
   var APP_URL = <?php echo json_encode(url('/')); ?>;
</script>
<script>
   $(document).ready(function(){
       var openModal=<?php echo $openModal; ?>;
       if(openModal==1)
       {
               $('#stateModal').modal('show');
       }
   });
</script>
<script type="text/javascript">
   function saveDrone()
   {
     
     var editedOrFreshEntries=<?php echo $openModal; ?>;
     var category=$("#category"). val();
     var uaopnumber=$("#uaopnumber"). val();
     var uin=$("#uin"). val();
     var uinvalidity=$("#uinvalidity"). val();
     var uaopvalidity=$("#uaopvalidity"). val();
     var npnt=$("#npnt"). val();
     var d_serial_no=$("#d_serial_no"). val();
     var dan_no=$("#dan_no"). val();
     var drnModelNumber=$("#drnModelNumber"). val();
     var drnManufacturar=$("#drnManufacturar"). val();
     var insurance=$("#insurance"). val();
     var insVal=$("#insVal"). val();
      if(editedOrFreshEntries!=1)
      {
          if(category=='' || category==null)
          {
             alert("Select category Name");
             return false;
          }
           
          if(uaopnumber=='' || uaopnumber==null)
          {
             alert("Enter UAOP Number");
             return false;
          }
      }
       
      else
      {
          if(editedOrFreshEntries!=0)
          {
              if(category=='' || category==null)
              {
                 alert("Select category");
                 return false;
              }
               
              if(uaopnumber=='' || uaopnumber==null)
          {
             alert("Enter UAOP Number");
             return false;
          }
          } 
      }
       
       
       
       swal({
             title: "Are you sure?",
             text: "Save Drone Information !",
             icon: "warning",
             buttons: [
               'No !',
               'Yes !'
             ],
             dangerMode: true,
           }).then(function(isConfirm) {
             if (isConfirm) {
               swal({
                 title: 'Drone Information Saved!',
                 text: 'Drone Information Saved successfully!',
                 icon: 'success'
               }).then(function() {
                 
                           var url =APP_URL+'/pilotdroneinfo';
                           $.ajax({
                             headers: { 'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content') },
                             type: "POST",
                             url: url,
                              data:{
                                  'editedOrFreshEntries':editedOrFreshEntries,
                                  'category': category,
                                  'uaopnumber': uaopnumber,
                                  'uin': uin,
                                  'uaopvalidity':uaopvalidity,
                                  'uinvalidity': uinvalidity,
                                  'npnt': npnt,
                                  'd_serial_no': d_serial_no,
                                  'dan_no': dan_no,
                                  'drnModelNumber': drnModelNumber,
                                  'drnManufacturar': drnManufacturar,
                                  'insurance': insurance,
                                  'insVal': insVal,
                               
                                  },
                            //  data:$('#myForm').serializeArray(),
                             success: function(newdata)
                             {
                               window.location = url;
                             }
   
                           });
               });
             } else {
               swal("Cancelled", "Your are cancelled :)", "error");
             }
           });
   
   }
   
   
   function deleteDrone(id)
   {
   
       swal({
             title: "Are you sure?",
             text: "Delete Drone Information !",
             icon: "warning",
             buttons: [
               'No !',
               'Yes !'
             ],
             dangerMode: true,
           }).then(function(isConfirm) {
             if (isConfirm) {
               swal({
                 title: 'Delete Drone Information!',
                 text: 'Drone Information Deleted successfully!',
                 icon: 'success'
               }).then(function() {
                 
                           var url =APP_URL+'/pilotdroneinfo';
                           $('#loader').show();
                           $.ajax({
                             headers: { 'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content') },
                             type: "GET",
                             url: url,
                              data:{
                                   'deleteOrEditDrone':'deleteDrone',
                                   'id': id,
                                    },
                             success: function(newdata)
                             {
                               window.location = url;
                              
                            }
   
                           });
               });
             } else {
               swal("Cancelled", "Your are cancelled :)", "error");
             }
           });
   }
</script>
<?php $__env->stopSection(); ?>




<script type="text/javascript">
    var APP_URL = <?php echo json_encode(url('/')); ?>

</script>



<script type="text/javascript">
    function ShowHideDiv() 
    {
        var category = document.getElementById("category").value;
        var categoryId=category.toString().split("*");
        var requiredDiv = document.getElementById("requiredDiv");
        requiredDiv.style.display = categoryId[1] == "1" ? "block" : "none";
    }
</script> 


<script type="text/javascript">
    function ShowHideInsDiv() 
    {
        var insurance = document.getElementById("insurance").value;
        // var categoryId=category.toString().split("*");
        var requiredInsDiv = document.getElementById("requiredInsDiv");
        requiredInsDiv.style.display = insurance == "1" ? "block" : "none";
    }
</script> 



<script type="text/javascript">
        function Validate() {
            var password = document.getElementById("password").value;
            var confirmPassword = document.getElementById("confpassword").value;
            if (password != confirmPassword) 
            {
                alert("Passwords do not match.");
                return false;
            }

        var category = document.getElementById("category").value;
        var categoryId=category.toString().split("*");
        
        if(categoryId[1]==1)
        {
           
          var uaopnumber=$("#uaopnumber"). val();
           
            if(uaopnumber=='' || uaopnumber==null)
               {
                 alert("Enter UAOP Name");
                 return false;
               }
               
               
           var uaopvalidity=$("#uaopvalidity"). val();
           
            if(uaopvalidity=='' || uaopvalidity==null)
               {
                 alert("Select UAOP Validity");
                 return false;
               }
               
               
               
               var npnt=$("#npnt"). val();
           
            if(npnt=='' || npnt==null)
               {
                 alert("Enter NPNT");
                 return false;
               }
               
               
               
               var ftoId=$("#ftoId"). val();
           
            if(ftoId=='' || ftoId==null)
               {
                 alert("Select FTO Name");
                 return false;
               }
            
        }
        
            return true;
        }
</script>
<?php echo $__env->make('pilot.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sumagoinfotech/public_html/rpa/resources/views/pilot/pilotdroneinfo/pilotdrone.blade.php ENDPATH**/ ?>