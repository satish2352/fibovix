	
	<script src="<?php echo e(asset('vendors/scripts/script.js')); ?>"></script>

	<div class="footer-wrap bg-white pd-20 mb-20 border-radius-5 box-shadow">
		<?php $year=date("Y"); ?>
		Copyright © <?php echo e($year); ?> RAYS AVIATION TECHNOLOGIES LLP. 
	</div>
			</div>
	</div>

	

	</body>
</html><?php /**PATH C:\xampp\htdocs\rpapilot\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>