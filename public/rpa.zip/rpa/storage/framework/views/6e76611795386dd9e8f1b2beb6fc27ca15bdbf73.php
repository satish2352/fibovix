<div class="form-row justify-content-between">
<div class="form-group col-md-6">
    <label for="createInputState">City <span class="text-primary">*</span></label>
        <select name="city" id="cityFinalNew" class="form-control " title="Choose..." data-live-search="true" required>
        <option value="" >Choose City</option>
        <?php $__currentLoopData = $cityList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($city['id']); ?>" ><?php echo e($city['name']); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
        </select>
</div>
</div>



<!--<div class="form-group col-md-6" id="city" >-->
<!--                                    <label for="">Password Confirmation<span class="text-primary">*</span></label>-->
<!--                                    <select name="city" class="selectpicker form-control " title="Choose..." data-live-search="true" required>-->
<!--                                    <option value="" >Choose City</option>-->
<!--                                    <?php $__currentLoopData = $cityList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
<!--                                    <option value="<?php echo e($city['id']); ?>" ><?php echo e($city['name']); ?></option>-->
<!--                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            -->
<!--                                    </select>-->
<!--                                </div>-->


<?php /**PATH /home/rpapilot/public_html/rpa/resources/views/common/city.blade.php ENDPATH**/ ?>