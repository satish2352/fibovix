
<?php $__env->startSection('title'); ?>
    About
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('website.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('website.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


 <div class="row text-center justify-content-center" style="margin-top: 15px;">
            <div class="col-md-10">
                <h1 class=" text-uppercase text-primary">Upload Textbook</h1>

            </div>
        </div>
<div class="row position-relative">
        <div class="container my-5" style="max-width: 800px">
            <div class="col-md-12">
                <div class="card shadow" style="margin-bottom: 150px;">
                    <div class="card-body">
                        <form action="<?php echo e(route('saveuploadtpmform')); ?>" method="POST" class="mb-5" enctype="multipart/form-data">
                              <?php echo csrf_field(); ?> 
                                  <div class="form-row justify-content-between">
                                
                                <div class="form-group col-md-12">
                                    <label for="">Title <span class="text-primary">*</span></label>
                                    <input name="title" type="text" class="form-control" id=""
                                        placeholder="Provide Title" value="" required="">
                                </div>

                                <div class="form-group col-md-12">
                                   <label for="createInputDescription">Description<span class="text-primary">*</span></label>
                                <textarea name="description" class="form-control" id="createInputDescription"
                                          placeholder="Provide Description"
                                          rows="8" required=""></textarea>
                                </div>

                               
                                <div class="form-group col-md-12">
                                   <label for="">Upload<span class="text-primary">*</span></label><br>
                                   <!-- <img src="/asset/vendors/upload/No-image-full.jpg" height="100" width="100" /><br> -->
                                   <input type="file" id="image" name="photoUpload"  accept=".pdf, .png, .jpg, .jpeg "  required="" />
                                </div>
                            <div class="form-group col-md-6">
                                <button type="submit" class="btn btn-primary w-100">Submit</button>
                            </div>
                            <div class="form-group col-md-6">
                                <button type="reset" class="btn btn-primary w-100">Reset</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>

    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
</div>
  <!--  <script type="text/javascript">
            $(document).ready(function(){
                //Image file input change event
                $("#image").change(function(){
                    readImageData(this);//Call image read and render function
                });
            });
             
            function readImageData(imgData){
                if (imgData.files && imgData.files[0]) {
                    var readerObj = new FileReader();
                    
                    readerObj.onload = function (element) {
                        $('#preview_img').attr('src', element.target.result);
                    }
                    
                    readerObj.readAsDataURL(imgData.files[0]);
                }
            }
        </script> -->


   <?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sumagoinfotech/public_html/rpa/resources/views/fto/uploadTPM/uploadtpm.blade.php ENDPATH**/ ?>