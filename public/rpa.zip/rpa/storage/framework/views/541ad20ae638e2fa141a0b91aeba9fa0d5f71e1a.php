	<!-- js -->
	<script src="<?php echo e(asset('vendors/scripts/script.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\rpapilot\resources\views/admin/layout/script.blade.php ENDPATH**/ ?>