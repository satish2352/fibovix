<!DOCTYPE HTML>
<html>
	<head>
		<title>Erro Page</title>
		
		<style>

/*end reset*
 */
body{
	background: url(../images/bg1.png);
	font-family: "Century Gothic",Arial, Helvetica, sans-serif;
	}
.content p{
	margin: 18px 0px 45px 0px;
}
.content p{
	font-family: "Century Gothic";
	font-size:2em;
	color:#666;
	text-align:center;
}
.content p span,.logo h1 a{
	color:#e54040;
}
.content{
	text-align:center;
	padding:115px 0px 0px 0px;
}
.content a{
	color:#fff;
	font-family: "Century Gothic";
	background: #666666; /* Old browsers */
	background: -moz-linear-gradient(top,  #666666 0%, #666666 100%); /* FF3.6+ */
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#666666), color-stop(100%,#666666)); /* Chrome,Safari4+ */
	background: -webkit-linear-gradient(top,  #666666 0%,#666666 100%); /* Chrome10+,Safari5.1+ */
	background: -o-linear-gradient(top,  #666666 0%,#666666 100%); /* Opera 11.10+ */
	background: -ms-linear-gradient(top,  #666666 0%,#666666 100%); /* IE10+ */
	background: linear-gradient(to bottom,  #666666 0%,#666666 100%); /* W3C */
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#666666', endColorstr='#666666',GradientType=0 ); /* IE6-9 */
	padding: 15px 20px;
	border-radius: 1em;
}
.content a:hover{
	color:#e54040;
}
.logo{
	text-align:center;
	-webkit-box-shadow: 0 8px 6px -6px rgb(97, 97, 97);
	-moz-box-shadow: 0 8px 6px -6px  rgb(97, 97, 97);
	box-shadow: 0 8px 6px -6px  rgb(97, 97, 97);
}
.logo h1{
	font-size:2em;
	font-family: "Century Gothic";
	background: #666666; /* Old browsers */
	background: -moz-linear-gradient(top,  #666666 0%, #666666 100%); /* FF3.6+ */
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#666666), color-stop(100%,#666666)); /* Chrome,Safari4+ */
	background: -webkit-linear-gradient(top,  #666666 0%,#666666 100%); /* Chrome10+,Safari5.1+ */
	background: -o-linear-gradient(top,  #666666 0%,#666666 100%); /* Opera 11.10+ */
	background: -ms-linear-gradient(top,  #666666 0%,#666666 100%); /* IE10+ */
	background: linear-gradient(to bottom,  #666666 0%,#666666 100%); /* W3C */
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#666666', endColorstr='#666666',GradientType=0 ); /* IE6-9 */	
	padding: 10px 10px 18px 10px;
}
.logo h1 a{
	font-size:1em;
}
.copy-right{
	padding-top:20px;
}
.copy-right p{
	font-size:0.9em;
}
.copy-right p a{
	background:none;
	color:#e54040;
	padding:0px 0px 5px 0px;
	font-size:0.9em;
}
.copy-right p a:hover{
	color:#666;
}
/*------responive-design--------*/
@media  screen and (max-width: 1366px)	{
	.content {
		padding: 58px 0px 0px 0px;
	}
}
@media  screen and (max-width:1280px)	{
	.content {
		padding: 58px 0px 0px 0px;
	}
}
@media  screen and (max-width:1024px)	{
	.content {
		padding: 58px 0px 0px 0px;
	}
	.content p {
		font-size: 1.5em;
	}
	.copy-right p{
		font-size:0.9em;
		
	}
}
@media  screen and (max-width:640px)	{
	.content {
		padding: 58px 0px 0px 0px;
	}
	.content p {
		font-size: 1.3em;
	}
	.copy-right p{
		font-size:0.9em;
	}
}
@media  screen and (max-width:460px)	{
	.content {
		padding:20px 0px 0px 0px;
		margin:0px 12px;
	}
	.content p {
		font-size:0.9em;
	}
	.copy-right p{
		font-size:0.8em;
	}
}
@media  screen and (max-width:320px)	{
	.content {
		padding:30px 0px 0px 0px;
		margin:0px 12px;
	}
	.content a {
		padding:10px 15px;
		font-size:0.8em;
	}
	.content p {
		margin: 18px 0px 22px 0px;
	}
}
		</style>
	</head>
<body>
    
   		<!--start-wrap--->
		<div class="wrap">
			<!---start-header---->
				<!--<div class="header">-->
				<!--	<div class="logo">-->
				<!--		<h1><a href="#"></a></h1>-->
				<!--	</div>-->
				<!--</div>-->
				<!---728x90--->

			<!---End-header---->
			<!--start-content------>
			<div class="content">
				<img src="<?php echo e(env('APP_URL')); ?>/public/asset/website/error-img.png" style="heigh:150px"/>
				<!---728x90--->

				<p>You Requested the page that is no longer There.</p>
				
				<a href="http://rpapilot.com/reportanerror">Report An Error</a>
				<!---728x90--->

				<div class="copy-right">
					<p>&copy; <?php echo date('Y'); ?>. All Rights Reserved |<a href="http://rpapilot.com/">RPA Pilot</a></p>
				</div>
   			</div>
			<!--End-Cotent------>
		</div>
		<!--End-wrap--->
	</body>
</html><?php /**PATH /home/rpapilot/public_html/rpa/resources/views/websiteerror.blade.php ENDPATH**/ ?>