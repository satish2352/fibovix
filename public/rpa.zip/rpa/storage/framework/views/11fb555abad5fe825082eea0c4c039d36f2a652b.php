<?php $__env->startSection('title'); ?>
    Search Course
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('website.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('website.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<?php $CommonService = app('App\Http\Controllers\Common\CommonController'); ?>



<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {box-sizing: border-box;}
body {font-family: Verdana, sans-serif;}
.mySlides {display: none;}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

.card-body1 {
  flex: 1 1 auto;
  padding: 0.15rem;
}
card-text1 {
    margin-top: 0;
    margin-bottom: 0.15rem;
}
@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes  fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media  only screen and (max-width: 300px) {
  .text {font-size: 11px}
}
</style>


  <div class="row text-center justify-content-center" style="margin-top: 15px;">
      <div class="col-md-12">
          <h1 class=" text-uppercase text-primary">COURSE SEARCH</h1>

      </div>
  </div>
  <div class="container my-5">
   <div class="card box-shadow-1 mb-2">
    <div class="card-body">
      <div class="row">
        <div class="slideshow-container">
             <?php
            foreach($allPilotsAdvertise as $getallPilotsAdvertise)
                {
            ?>
            <div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img src="public/asset/Advertise/Image/<?php echo e($getallPilotsAdvertise->image); ?>" alt="Lights" style="width:100%;height:150px">
  <div class="text"><?php echo e($getallPilotsAdvertise->title); ?></div>
</div>
             
           
            <?php
                }
            ?>
            
            <br>

<div style="text-align:center">
    <?php $__currentLoopData = $allPilotsAdvertise; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getallPilotsAdvertise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <span class="dot"></span> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
            </div>
      </div>
    </div>
    </div>  
      
      <div class="card box-shadow-1">
    <div class="card-body">
               
                  <div class="row">
                      
                     <div class="form-group col-sm-3">
                         <label>State</label>
                        <select name="state" id="stateId" class="form-control" onchange="getResult();" title="Choose..." data-live-search="true" required>
                           <option value="">Choose State</option>
                           <?php $__currentLoopData = $stateList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($state->id); ?>" ><?php echo e($state->state); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
                        </select>
                     </div>
                      <div class="form-group col-sm-3">
                    		<label>City</label>
                    		    <select class="form-control" name="city" required="" id="city" onchange="getResult();" class="custom-select col-12">
                    		        <option value="">Select City</option>
                                            <?php $__currentLoopData = $cityList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cityListNew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <option value="<?php echo e($cityListNew->id); ?>"><?php echo e($cityListNew->city); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    		    </select>
                       </div>
                        
                        <div class="form-group col-sm-3">
                    		<label>Course</label>
                    		    <select class="form-control" name="course" required="" id="course" onchange="getResult();" class="custom-select col-12">
                    		        <option value="">Select Course</option>
                                            <?php $__currentLoopData = $allCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getallCourses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                                           <option value="<?php echo e($getallCourses->id); ?>"><?php echo e($getallCourses->courseName); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    		    </select>
                       </div>
                       
                       <div class="form-group col-sm-3">
                    		<label>Course Duration</label>
                    		    <select class="form-control" name="courseDuration" required="" id="courseDuration" onchange="getResult();" class="custom-select col-12">
                    		        <option value="">Select Course Duration</option>
                                            <?php $__currentLoopData = $courseDuration; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseDurationNew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                                           <option value="<?php echo e($courseDurationNew->id); ?>"><?php echo e($courseDurationNew->duration); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    		    </select>
                       </div>
                       
                     <div class="form-group col-sm-4">
                     </div>
                  </div>
           <div id="tableAjax">
            <div class="row table-responsive ">
            <table class="table table-hover" id="pageDataTable" role="grid" aria-describedby="DataTables_Table_0_info" style="border: none;">
            <thead>
            <tr style="border: none;">
              <td style="border: none;"></td>
            </tr>
            </thead>
            <tbody>
                  <?php if(count($allCourses) > 0): ?>
            <?php
               foreach($allCourses as $getallCourses )
                   {
            ?>
            <tr style="border-style: none;">
              <td style="border: none;">
                
                <div class="card box-shadow-1 mb-2">
                <div class="card-body1">
                <div class="row no-gutters">
                 <div class="col-md-6 courses-card-image">
                    <center>
                        
                        <?php
                           if($getallCourses->image)
                           {
                           ?>
                           <img src="public/asset/Course/Image/<?php echo e($getallCourses->image); ?>" style="height: 150px; width: 200px; margin-top: 10px">
                       
                        <?php
                           }
                           else
                           {
                           ?>
                           <img src="public/asset/noImage.png" style="height: 150px; width: 200px; margin-top: 10px">
                       
                        <?php
                           }
                           ?>
                      <!--<img src="<?php echo e(asset('website/images/GreenTown.png')); ?>" style="height: 150px; width: 200px; margin-top: 10px">-->
                    </center>
                 </div>
                 <div class="col-md-6">
                  <div class="card-body">
                      
                    <h5 class="card-title">Category: <?php echo e($getallCourses->category); ?></h5>
                    <p class="card-text1">Course Name: <?php echo e($getallCourses->courseName); ?></p>
                    <p class="card-text1">Duration: <?php echo e($getallCourses->duration); ?></p>
                    <p class="card-text1">Price: <?php echo e($getallCourses->price); ?></p>
                    <p class="card-text1">State: <?php $state=$CommonService->getPerticularAdminStateById($getallCourses->state);?>  <?php echo e($state[0]->state); ?></p>
                    <p class="card-text1">City: <?php $city=$CommonService->getPerticularAdminCityById($getallCourses->city);?>  <?php echo e($city[0]->city); ?></p>
                    <form action="<?php echo e(route('studentregistration')); ?>" method="POST" >
                            <?php echo csrf_field(); ?>
                    <a class="btn btn-primary" href="<?php echo e(route('webcoursedetails',array('id'=>$getallCourses->id))); ?>">Details</a>
                    <button type="submit" class="btn btn-primary" align="right">Get Now</button>
                    <input type="text" name="courseId" class="btn btn-primary" value="<?php echo e($getallCourses->id); ?>" hidden>
                    </form>
    
                  </div>
                </div>
            </div>
        </div>
    </div>
  </td>
</tr>
            <?php
                }
                ?>
                <?php endif; ?>
            </tbody>
            </table>
            </div>
            </div>
        </div>
        </div>    
            
          <div class="card box-shadow-1 mb-2">
    <div class="card-body">   
            
             <div class="row">
        <div class="slideshow-container">
             <?php
            foreach($allPilotsAdvertise as $getallPilotsAdvertise)
                {
            ?>
            <div class="mySlidesnew fade">
  <div class="numbertext">1 / 3</div>
  <img src="public/asset/Advertise/Image/<?php echo e($getallPilotsAdvertise->image); ?>" alt="Lights" style="width:100%;height:150px">
  <div class="text"><?php echo e($getallPilotsAdvertise->title); ?></div>
</div>
             
           
            <?php
                }
            ?>
            
            <br>

<div style="text-align:center">
    <?php $__currentLoopData = $allPilotsAdvertise; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getallPilotsAdvertise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <span class="dotnew"></span> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
            </div>
      </div>  
      </div>
    </div>    
</div>
<script type="text/javascript">
   function getResult()
   {
      var stateId=document.getElementById('stateId').value;
      var cityId=document.getElementById('city').value;
      var course=document.getElementById('course').value;
      var courseDuration=document.getElementById('courseDuration').value;
     var url =APP_URL+'/'+'webcourseserachajax';
     $('#tableAjax').empty();
     $.ajax({
               type: "post",
               url: url,
               data :{
                   "_token": "<?php echo e(csrf_token()); ?>",
                   'stateId':stateId,
                   'cityId':cityId,
                   'course':course,
                   'courseDuration':courseDuration,
               },
               success: function(newdata)
               {
                 $('#tableAjax').empty();
                 $('#tableAjax').append(newdata);
   
               }
   
             });
   }
</script>
<script type="text/javascript">
//   function getResultByCity(cityId)
//   {
//      var stateId=document.getElementById('stateId').value;
//      $('#tableAjax').empty();
//      var url =APP_URL+'/'+'webpilotsearchbystatecity';
//      $.ajax({
//               type: "post",
//               url: url,
//               data :{
//                   "_token": "<?php echo e(csrf_token()); ?>",
//                   'stateId':stateId,
//                   'cityId':cityId,
//               },
//               success: function(newdata)
//               {
//                  $('#tableAjax').empty();
//                  $('#tableAjax').append(newdata);
   
//               }
   
//              });
 //  }
</script>



<script>
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 2000); // Change image every 2 seconds
}
</script>


<script>
var slideIndex = 0;
showSlidesnew();

function showSlidesnew() {
  var i;
  var slides = document.getElementsByClassName("mySlidesnew");
  var dots = document.getElementsByClassName("dotnew");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlidesnew, 2000); // Change image every 2 seconds
}
</script>




<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sumagoinfotech/public_html/rpa/resources/views/website/courses/coursesearch.blade.php ENDPATH**/ ?>