<?php $CommonService = app('App\Http\Controllers\Common\CommonController'); ?>
<div class="row">

   <div class="form-group col-sm-4">
   </div>
</div>
</form>
<div class="row table-responsive ">
   <table class="table table-hover" id="pageDataTable" role="grid" aria-describedby="DataTables_Table_0_info" style="border: none;">
            <thead>
            <tr style="border: none;">
              <td style="border: none;"></td>
            </tr>
            </thead>
            <tbody>
                  <?php if(count($allCourses) > 0): ?>
            <?php
               foreach($allCourses as $getallCourses )
                   {
            ?>
            <tr style="border-style: none;">
              <td style="border: none;">
                
                <div class="card box-shadow-1">
                <div class="card-body1">
                <div class="row no-gutters">
                 <div class="col-md-6 courses-card-image">
                    <center>
                      <img src="<?php echo e(asset('website/images/GreenTown.png')); ?>" style="height: 200px; width: 200px; margin-top: 50px">
                    </center>
                 </div>
                 <div class="col-md-6">
                  <div class="card-body">
                      
                    <h5 class="card-title">Category: <?php echo e($getallCourses->category); ?></h5>
                    <p class="card-text1">Course Name: <?php echo e($getallCourses->courseName); ?></p>
                    <p class="card-text1">Duration: <?php echo e($getallCourses->duration); ?></p>
                    <p class="card-text1">Price: <?php echo e($getallCourses->price); ?></p>
                    <p class="card-text1">State: <?php $state=$CommonService->getPerticularAdminStateById($getallCourses->state);?>  <?php echo e($state[0]->state); ?></p>
                    <p class="card-text1">City: <?php $city=$CommonService->getPerticularAdminCityById($getallCourses->city);?>  <?php echo e($city[0]->city); ?></p>
                    <form action="<?php echo e(route('studentregistration')); ?>" method="POST" >
                            <?php echo csrf_field(); ?>
                    <a class="btn btn-primary" href="<?php echo e(route('webcoursedetails',array('id'=>$getallCourses->id))); ?>">Details</a>
                    <button type="submit" class="btn btn-primary" align="right">Get Now</button>
                    <input type="text" name="courseId" class="btn btn-primary" value="<?php echo e($getallCourses->id); ?>" hidden>
                    </form>
    
                  </div>
                </div>
            </div>
        </div>
    </div>
  </td>
</tr>
            <?php
                }
                ?>
                <?php endif; ?>
            </tbody>
            </table>
</div>

<script>
    $(document).ready(function(){
    $('#pageDataTable').DataTable({searching: false,ordering: false,lengthChange: false,showNEntries: false});
  });
</script><?php /**PATH /home/rpapilot/public_html/rpa/resources/views/website/courses/coursesearchajax.blade.php ENDPATH**/ ?>