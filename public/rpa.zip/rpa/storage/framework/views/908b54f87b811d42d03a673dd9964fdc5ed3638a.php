<?php $__env->startSection('title'); ?>
    Pilot Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('website.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('website.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container my-5">
     <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$pilot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row justify-content-between">
                <div class="div col-md-8 order-md-1 order-2">
                    <div class="card  box-shadow-1 my-2">
                        <div class="card-body">
                            <h5 class="card-title">Description</h5>
                            <p class="card-text"><?php echo e($pilot->experience); ?></p>
                        </div>
                    </div>
                    <!--                    <div class="card  box-shadow-1  my-2">-->
                    <!--    <div class="card-body">-->
                    <!--        <h5 class="card-title">My Videos</h5>-->
                    <!--        <div class="card-text d-flex justify-content-between">-->

                                                                                                                                                                                                                                                                                                                                                                                    
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                                    </div>
                <div class="col-md-4  order-md-1">
                    <div class="card position-relative">
                        <div class="fto-pilots-card-active-badge">
                                                            <span class="box-shadow-1 font-weight-normal align-middle  badge badge-success badge-pill text-white mx-1" style="font-size: 12px"><i class="material-icons-outlined" style="font-size: 18px">check</i> RPA Verified</span>
                                                                                        <span class="box-shadow-1 font-weight-normal align-middle  badge badge-info badge-pill text-white mx-1" style="font-size: 12px"><i class="material-icons-outlined" style="font-size: 18px">check</i> FTO  Verified</span>
                                                    </div>
                        
                        <div class="card-header text-center">
                            <img class="img-fluid" src="http://rpapilot.com/rpa/public//images/pilots/rpapilot_default_300_300.png">
                        </div>
                       
                        <div class="card-body">
                            <h3 class="card-title align-items-center"><?php echo e($pilot->firstName); ?> <?php echo e($pilot->middleName); ?> <?php echo e($pilot->lastName); ?>  </h3>
                            <h6 class="card-subtitle mb-2 text-muted"><?php //$proffession=$pilot->proffession; $resultNew=DB::select("select FTOName from ftoregistration where id='".$proffession."'"); ?> </h6>
                        </div>
                        <ul class="list-group list-group-flush"><?php //dd("hello"); ?>
                            <li class="list-group-item"><span class="font-weight-bold">FTO : </span><?php $ftoId=$pilot->ftoId; if($ftoId!=null) { $resultNew=DB::select("select FTOName from ftoregistration where id='".$ftoId."'"); echo $resultNew->FTOName; } ?> </li>
                            <li class="list-group-item"><span class="font-weight-bold">UAOP NO : </span><span class="text-primary"> <?php if(count($pilotrdroneinfo)): ?> <?php $__currentLoopData = $pilotrdroneinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$pilotDrone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($pilotDrone->uaopnumber); ?>,<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?> </span></li>
                            <li class="list-group-item"><span class="font-weight-bold">Email Address : </span><?php echo e($pilot->email); ?></li>
                            <li class="list-group-item"><span class="font-weight-bold">Mobile No : </span><?php echo e($pilot->mobile); ?></li>
                            <li class="list-group-item"><span class="font-weight-bold">Drone Serial Number : </span><?php if(count($pilotrdroneinfo)): ?>  <?php $__currentLoopData = $pilotrdroneinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$pilotDrone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($pilotDrone->droneSerialNumber); ?>,<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>
                            </li>
                            <li class="list-group-item"><span class="font-weight-bold">UIN : </span><?php if(count($pilotrdroneinfo)): ?>  <?php $__currentLoopData = $pilotrdroneinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$pilotDrone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($pilotDrone->uinnumber); ?>,<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?></li>
                            <li class="list-group-item"><span class="font-weight-bold">State : </span><?php $stateID=$pilot->stateID; $resultNew=DB::select("SELECT * FROM `states` where id='".$stateID."'"); ?> <?php echo e($resultNew[0]->name); ?></li>
                            <li class="list-group-item"><span class="font-weight-bold">City : </span><?php $cityId=$pilot->cityId; $resultNew=DB::select("SELECT * FROM `cities` where id='".$cityId."'"); ?> <?php echo e($resultNew[0]->name); ?></li>

                        </ul>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            
        </div>
        
        
  <?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sumagoinfotech/public_html/rpa/resources/views/website/pilot/pilotdetails.blade.php ENDPATH**/ ?>