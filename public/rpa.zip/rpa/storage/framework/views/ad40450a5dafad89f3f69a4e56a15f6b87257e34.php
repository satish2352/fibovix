<?php $__env->startSection('title'); ?>
    Verify a UOAP 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('website.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('website.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
   <div class="row text-center justify-content-center" style="margin-top: 15px;">
      <div class="col-md-12">
          <h1 class=" text-uppercase text-primary">Verify a Pilot</h1>
      </div>
    <?php if(session('error')): ?>
     <span class="alert alert-danger" role="alert">
         <strong><?php echo e(session('error')); ?></strong>
     </span>
    <?php endif; ?>
  </div>
  
    <div class="row justify-content-center position-relative">
        <div class="col-md-3" style="margin: 160px 0 !important;">
            <div class="container">
                <form action="<?php echo e(route('uaopverification')); ?>" method="POST" class="mb-5">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="">Enter UAOP Number</label>
                        <input name="uaop" type="text" class="form-control" id="" placeholder="Provide UAOP Number">
                    </div>
                    <button type="submit" class="btn btn-primary">Get Details</button>
                </form>
            </div>
        </div>
        <img src="<?php echo e(asset('website/images/cloud_pattern_blue.png')); ?>" class="index-cloud-pattern">
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rpapilot/public_html/rpa/resources/views/website/uaop-verification.blade.php ENDPATH**/ ?>