<?php $__env->startSection('content'); ?>

<div class="main-container">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
		<div class="pd-ltr-20 customscroll customscroll-10-p height-100-p xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Advisory Board</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo e(route('dashadmin')); ?>">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Advisory Board List</li>
								</ol>
							</nav>
						</div>
						<div class="col-md-6 col-sm-12 text-right">
							<div class="dropdown">
								<a href="#stateModal" class="btn btn-primary" role="button" data-toggle="modal" data-target="#stateModal">
								    Add Advisory Board
								</a>
								
								<div class="dropdown-menu dropdown-menu-right">
									<a class="dropdown-item" href="#">Export List</a>
									<a class="dropdown-item" href="#">Policies</a>
									<a class="dropdown-item" href="#">View Assets</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			
				<!-- Export Datatable start -->
				<div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
					<div class="clearfix mb-20">
						<div class="pull-left">
							<h5 class="text-blue">Advisory Board List</h5>
						</div>
					</div>
					<div class="row table-responsive ">
                     	<table class="table table-striped" id="pageDataTable" role="grid" aria-describedby="DataTables_Table_0_info">
							<thead>
								<tr>
								    <th>Sr.No.</th>
									<th>Name</th>
									<th>Designation</th>
									<th>Photo</th>
									<th>Status</th>
									<!--<th>Action</th>-->
								</tr>
							</thead>
							<tbody>
							    <?php $__currentLoopData = $allAdvisoryBoard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$getallAdvisoryBoard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($getallAdvisoryBoard->category); ?></td>
                                    <td><?php if($getallAdvisoryBoard->addInfoReq==1): ?> <?php echo e('Yes'); ?> <?php else: ?> <?php echo e('No'); ?> <?php endif; ?></td>
                                    <td><?php if($getallAdvisoryBoard->status==0): ?> <?php echo e('Active'); ?> <?php else: ?> <?php echo e('Not Active'); ?> <?php endif; ?></td>
                                    <!--<td>-->
                                    <!--  <a href="<?php echo e(route('advisoryBoardlist',['categoryId'=>$value->id,'deleteOrEditState'=>'editstate'])); ?>" class="btn btn-edit btn-lg">-->
                                    <!--    <i class="icon-copy fi-pencil btngreen" title="Edit"></i>-->
                                    <!--  </a>-->
                           
                                      
                                    <!--  <a onclick="deleteCategory(<?php echo e($value->id); ?>)" class="btn btn-delete btn-lg">-->
                                    <!--    <i class="icon-copy fi-trash btndelete" title="Delete"></i>-->
                                    <!--    </a>-->
                                    <!--</td>-->
                                    
                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							    
							 <!--   <tr>-->
							        
								<!--    <td>1</td>-->
								<!--	<td>Maharastra</td>-->
								<!--	<td>-->
								<!--	   	<button class="btn btn-danger" role="button">-->
        <!--								    <i class="fa fa-thumbs-down"></i>-->
        <!--								</button>-->
        <!--                        	</td>-->
								    
								<!--	<td>-->
								<!--	    <a class="btn btn-primary" href="#" role="button" >-->
								<!--	        View-->
								<!--        </a>-->
								<!--    </td>-->
								<!--</tr> -->
																


							</tbody>
						</table>
					</div>
				</div>
				<!-- Export Datatable End -->
			</div>
		
</div>



<!-- Modal -->
<div class="modal fade" id="stateModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button> -->
        <h4 class="modal-title" id="myModalLabel"><center>Add Advisory Board</center></h4>
      </div>
      <div class="modal-body">
        	    <form action="<?php echo e(route('saveadvisoryboard')); ?>" method="POST" enctype="multipart/form-data">
					    <?php echo csrf_field(); ?>
					    
					    <div class="form-group row">
							<label class="col-sm-12 col-md-1 col-form-label"><span style="color: red">*</span></label>
							<div class="col-sm-12 col-md-11">
								<input class="form-control" type="text" name="advName" id="" placeholder="Enter Advisory Name" required="" >
								
							</div>
						</div>
						
						<div class="form-group row">
							<label class="col-sm-12 col-md-1 col-form-label"><span style="color: red">*</span></label>
							<div class="col-sm-12 col-md-11">
								<input class="form-control" type="text" name="adsDesign" id="" placeholder="Enter Advisory Designation" required="" >
								
							</div>
						</div>
						
						
					    <div class="form-group row">
							<label class="col-sm-12 col-md-1 col-form-label"><span style="color: red">*</span></label>
							<div class="col-sm-12 col-md-11">
								<input class="form-control" type="text" name="advTitle" id="" placeholder="Enter Title" required="" >
								
							</div>
						</div>
						
						<div class="form-group row">
							<label class="col-sm-12 col-md-1 col-form-label"><span style="color: red">*</span></label>
							<div class="col-sm-12 col-md-11">
							    <textarea class="form-control" name="advContent" placeholder="Content" required=""></textarea>
							</div>
						</div>
						
						<div class="form-group row">
							<label class="col-sm-12 col-md-1 col-form-label"><span style="color: red">*</span>IMG</label>
							<div class="col-sm-12 col-md-11">
								<input class="form-control" type="file" name="image" accept=".png, .jpg" required="">
							</div>
						</div>
						
					
				        <div class="modal-footer">
                           <button class="btn btn-success" type="submit" >
		                        Submit
                           </button>
          
                           <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        </div>	
						
 </form>
      </div>
      
    </div>
  </div>
</div>


</div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sumagoinfotech/public_html/rpa/resources/views/admin/website/advisoryboard/advisoryboard.blade.php ENDPATH**/ ?>