<?php $__env->startSection('title'); ?>
    Course Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('website.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('website.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $CommonService = app('App\Http\Controllers\Common\CommonController'); ?>
<?php
            foreach($courseDetails as $getcourseDetails)
                {
                    
		        ?>
		        
<div class="container  my-5">
        <div class="row justify-content-center">

            <div class="div col-md-8 order-md-1 order-2">
                                                          
                        <div class="card  box-shadow-1 mb-2">
                            <div class="card-body">
                                <h5 class="card-title">Description</h5>
                                <p class="card-text"><?php echo e($getcourseDetails->description); ?></p>
                            </div>
                        </div>
            </div>

            <div class="div col-md-4 mb-2">
                <div class="card box-shadow-1">
                    <img src="<?php echo env('APP_URL'); ?>public/asset/Course/Image/<?php echo e($getcourseDetails->image); ?>" height="200px" class="card-img-top" alt="...">
                    
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><span class="">Course Name </span>
                            <div class="text-primary"><?php echo e($getcourseDetails->courseName); ?></div>
                        </li>
                        <li class="list-group-item"><span class="">Category </span>
                            <div class="text-primary"><?php echo e($getcourseDetails->category); ?></div>
                        </li>
                        
                        <li class="list-group-item">
                        <span>Price : </span><span class="text-primary"><?php echo e($getcourseDetails->price); ?> </span>
                                
                        </li>
                        <li class="list-group-item"><span class="">Duration </span>
                            <div class="text-primary"><?php echo e($getcourseDetails->duration); ?></div>
                        </li>
                        <li class="list-group-item"><span class="">State : </span><span class="text-primary"><?php $state=$CommonService->getPerticularAdminStateById($getcourseDetails->state);?>  <?php echo e($state[0]->state); ?></span></li>
                        <li class="list-group-item"><span class="">City : </span><span class="text-primary"><?php $city=$CommonService->getPerticularAdminCityById($getcourseDetails->city);?>  <?php echo e($city[0]->city); ?></span></li>
                        <li class="list-group-item"><span class="">PDF : </span><span class="text-primary ">
                            <a class="btn btn-primary" href="<?php echo env('APP_URL'); ?>public/asset/Course/Pdf/<?php echo e($getcourseDetails->pdf); ?>" target="_blank"> Download</a></span></li>
                        
                    </ul>
                </div>
            </div>
                                </div>
    </div>
    <?php
                }
                ?>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rpapilot/public_html/rpa/resources/views/website/courses/coursedetail.blade.php ENDPATH**/ ?>